/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    pinkFrame.h

  Copyright (c) ESIEE - Michel Couprie and and Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/


#ifndef PINKFRAME_H
#define PINKFRAME_H

#include <QtCore/QThread>
#include <mccodimage.h>
#include "boost/tuple/tuple.hpp"

class pinkFrame : public QThread
{
Q_OBJECT
private:
  const boost::tuple<std::string, std::string> &argv;
  struct xvimage * image;
  int32_t width; 
protected:
  virtual void run();
public:
    pinkFrame(boost::tuple<std::string, std::string> &);
    virtual ~pinkFrame();
signals:
  QThread *endCompute(QThread *);
};

#endif // PINKFRAME_H
