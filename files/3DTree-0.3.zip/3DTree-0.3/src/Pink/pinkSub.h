/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    pinkSub.h

  Copyright (c) ESIEE - Michel Couprie and and Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef PINKSUB_H
#define PINKSUB_H

#include <QThread>
#include <mccodimage.h>
#include "boost/tuple/tuple.hpp"

class pinkSub : public QThread
{
Q_OBJECT
private:
  struct xvimage * image1;
  struct xvimage * image2;
  const boost::tuple<std::string, std::string, std::string> &argv;
protected:
    virtual void run();
public:
    explicit pinkSub(boost::tuple<std::string, std::string, std::string> &);
    virtual ~pinkSub();
signals:
  QThread *endCompute(QThread *);
};

#endif // PINKSUB_H
