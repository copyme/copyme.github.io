/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    pinkAsft.h

  Copyright (c) ESIEE - Michel Couprie and and Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/


#ifndef PINKASFT_H
#define PINKASFT_H

#include <mccodimage.h>
#include "boost/tuple/tuple.hpp"
#include <QThread>

class pinkAsft : public QThread
{
Q_OBJECT  
private:
  struct xvimage *image;
  int32_t rayonmax;
  int32_t connex;
  boost::tuple<std::string, int, int, std::string> &argv;
  
protected:
  virtual void run();
public:
  pinkAsft(boost::tuple<std::string, int, int, std::string> &);
  virtual ~pinkAsft();
signals:
  QThread *endCompute(QThread *);
};

#endif // PINKASFT_H
