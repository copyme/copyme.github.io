/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    pinkPgmToRaw.h

  Copyright (c) ESIEE - Michel Couprie and Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef PINKPGMTORAW_H
#define PINKPGMTORAW_H

#include <boost/tuple/tuple.hpp>
#include <QThread>
#include <stdio.h>
#include <stdint.h>
#include <sys/types.h>
#include <stdlib.h>
#include <mcimage.h>
#include <mccodimage.h>

class pinkPgmToRaw : public QThread
{
Q_OBJECT
private:
    int32_t rs, cs, ds, N, ret;
    struct xvimage * image;
    FILE *fd;
    boost::tuple<std::string,std::string> &argv;    
protected:
    virtual void run();
public:
    virtual ~pinkPgmToRaw();
    pinkPgmToRaw(boost::tuples::tuple< std::string, std::string > &p_argv);
signals:
    void endCompute(QThread *); 
};

#endif // PINKPGMTORAW_H
