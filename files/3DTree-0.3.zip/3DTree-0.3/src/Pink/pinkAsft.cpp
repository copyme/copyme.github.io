/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    pinkAsft.cpp

  Copyright (c) ESIEE - Michel Couprie and and Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include <stdio.h>
#include <stdint.h>
#include <sys/types.h>
#include <stdlib.h>
#include <mcimage.h>
#include <lasft.h>

#include "pinkAsft.h"

pinkAsft::pinkAsft(boost::tuple<std::string, int, int, std::string> &p_argv) : argv(p_argv)
{
  image = readimage(boost::get<0>(argv).c_str());
  
  if (image == NULL)
  {
    fprintf(stderr, "%s: readimage failed\n", boost::get<0>(argv).c_str());
    exit(1);
  }

  rayonmax = boost::get<1>(argv);
  connex = boost::get<2>(argv);
}

pinkAsft::~pinkAsft()
{
  freeimage(image);
  this->quit();
  this->wait();
}

void pinkAsft::run()
{
  if (!lasft3d(image, NULL, NULL, connex, rayonmax))
  {
    fprintf(stderr, "%s: lasft3d failed\n", boost::get<0>(argv).c_str());
    exit(1);
  }

  writeimage(image,(char *)boost::get<3>(argv).c_str());
  
  endCompute(this);
  exec();
}

#include "pinkAsft.moc"
