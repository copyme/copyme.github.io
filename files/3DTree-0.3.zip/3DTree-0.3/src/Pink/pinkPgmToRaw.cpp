/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    pinkPgmToRaw.cpp

  Copyright (c) ESIEE - Michel Couprie and Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "pinkPgmToRaw.h"

pinkPgmToRaw::~pinkPgmToRaw()
{
  freeimage(image);
  this->quit();
  this->wait();  
}

pinkPgmToRaw::pinkPgmToRaw(boost::tuples::tuple< std::string, std::string > &p_argv) : argv(p_argv)
{
  fd = NULL;
  image = NULL;
}
void pinkPgmToRaw::run()
{
  image = readimage(boost::get<0>(argv).c_str());
  if (image == NULL)
  {
    fprintf(stderr, "pgm2raw: readimage failed\n");
    exit(1);
  }

  if ( (datatype(image) != VFF_TYP_1_BYTE) && (datatype(image) != VFF_TYP_4_BYTE) && (datatype(image) != VFF_TYP_FLOAT))
  {
    fprintf(stderr, "pgm2raw: only byte|long|float images supported\n");
    exit(1);
  }

  rs = rowsize(image);
  cs = colsize(image);
  ds = depth(image);
  N = rs * cs * ds;

#ifdef __unix
  fd = fopen(boost::get<1>(argv).c_str(),"w");
#endif
#ifdef WINNT
  fd = fopen(boost::get<1>(argv).c_str(),"wb");
#endif
  
  if (fd == NULL)
  {
    fprintf(stderr,"fopen failed for %s\n", boost::get<1>(argv).c_str());
    exit(1);
  }

  if(datatype(image) == VFF_TYP_1_BYTE)
  {
	ret = fwrite(UCHARDATA(image), sizeof(uint8_t), N, fd);
  }
  else if(datatype(image) == VFF_TYP_4_BYTE)
  {
  	ret = fwrite(ULONGDATA(image), sizeof(int32_t), N, fd);
  }
  else if(datatype(image) == VFF_TYP_FLOAT)
  {
  	ret = fwrite(FLOATDATA(image), sizeof(float), N, fd);
  }
  if (ret != N)
  {
    fprintf(stderr, "pgm2raw: only %d items written\n", ret);
    exit(1);
  }

  fclose(fd);
  
  endCompute(this);
  exec();
}
#include "pinkPgmToRaw.moc"
