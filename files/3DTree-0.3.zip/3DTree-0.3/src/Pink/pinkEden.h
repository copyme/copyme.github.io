/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    pinkEden.h

  Copyright (c) ESIEE - Hugues Talbot and and Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/


#ifndef EDEN_H
#define EDEN_H

#include <QtCore/QThread>

#include <stdio.h>
#include <stdint.h>
#include <sys/types.h>
#include <stdlib.h>
#include <mccodimage.h>
#include "boost/tuple/tuple.hpp"
#include <vtkImageData.h>

class pinkEden : public QThread
{
Q_OBJECT
private:
  struct xvimage * image1;
  index_t rs, cs, ds;
  int32_t niter, grow, shrink, topo;
  uint8_t *In;
 
  vtkImageData *rawTree;
  
  long long unsigned int voxCount;
  int dims[3];
  
  const boost::tuple<std::string,long long unsigned int,int, int, int, std::string, vtkImageData *> &argv;
protected:
    void VoxCounter();
    virtual void run();
public:
    virtual ~pinkEden();
    pinkEden(const boost::tuple<std::string,long long unsigned int,int, int, int, std::string, vtkImageData *> &);
signals:
  QThread *endCompute(QThread *);
};

#endif // EDEN_H
