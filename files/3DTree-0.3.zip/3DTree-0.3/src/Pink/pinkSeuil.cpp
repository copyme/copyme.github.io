/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    pinkSeuil.cpp

  Copyright (c) ESIEE - Kacper Pluta <kacperp@wsinf.edu.pl> and Pink Team
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/


#include "pinkSeuil.h"
#include <stdio.h>
#include <stdint.h>
#include <lseuil.h>

pinkSeuil::pinkSeuil(const boost::tuples::tuple< std::string, double, std::string> &p_argv) : argv(p_argv)
{
  image = readimage(boost::get<0>(argv).c_str());
  if (image == NULL)
  {
    fprintf(stderr, "%s: readimage failed\n", boost::get<0>(argv).c_str());
    exit(1);
  }
  
  seuil = boost::get<1>(argv);
}
pinkSeuil::~pinkSeuil()
{
  freeimage(image);
  this->quit();
  this->wait();
}

void pinkSeuil::run()
{
  if (!lseuil(image, seuil))
  {
    fprintf(stderr, "%s: function lseuil failed\n", boost::get<0>(argv).c_str());
    exit(1);
  }

  if (datatype(image) != VFF_TYP_1_BYTE)
  {
    rs = rowsize(image); cs = colsize(image); ds = depth(image); 
    N = rs * cs * ds; 
    imagebin = allocimage(image->name, rs, cs, ds, VFF_TYP_1_BYTE);
    if (imagebin == NULL)
    {
      fprintf(stderr, "%s: allocimage failed\n", boost::get<0>(argv).c_str());
      exit(1);
    }
    F = UCHARDATA(imagebin); 

    if (datatype(image) == VFF_TYP_4_BYTE)
    {
      int32_t *FL = SLONGDATA(image);
      for (x = 0; x < N; x++) F[x] = (uint8_t)FL[x];
    }
    else if (datatype(image) == VFF_TYP_2_BYTE)
    {
      int16_t *FL = SSHORTDATA(image);
      for (x = 0; x < N; x++) F[x] = (uint8_t)FL[x];
    }
    else if (datatype(image) == VFF_TYP_FLOAT)
    {
      float *FL = FLOATDATA(image);
      for (x = 0; x < N; x++) if (FL[x] == 0.0) F[x] = NDG_MIN; else F[x] = NDG_MAX;
    }
    else if (datatype(image) == VFF_TYP_DOUBLE)
    {
      double *FL = DOUBLEDATA(image);
      for (x = 0; x < N; x++) if (FL[x] == 0.0) F[x] = NDG_MIN; else F[x] = NDG_MAX;
    }
    else
    {
      fprintf(stderr, "%s: bad data type %d\n", boost::get<0>(argv).c_str(), datatype(image));
      exit(1);
    }
    writeimage(imagebin,(char *)boost::get<2>(argv).c_str());
    freeimage(imagebin);
  }
  else
  {
    writeimage(image,(char *)boost::get<2>(argv).c_str());
  }
  
  endCompute(this);
  exec();
}

#include "pinkSeuil.moc"