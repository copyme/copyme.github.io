/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    pinkFrame.cpp

  Copyright (c) ESIEE - Michel Couprie and and Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/


#include "pinkFrame.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <sys/types.h>
#include <stdlib.h>
#include <lcrop.h>
#include <mcimage.h>

pinkFrame::pinkFrame(boost::tuples::tuple< std::string, std::string >& p_argv): argv(p_argv)
{
  image = readimage(boost::get<0>(argv).c_str());
  width = 1;
}
pinkFrame::~pinkFrame()
{
  freeimage(image);
  this->quit();
  this->wait();
}
void pinkFrame::run()
{
  if (image == NULL)
  {
    fprintf(stderr, "%s: readimage failed\n", boost::get<0>(argv).c_str());
    exit(1);
  }
  
  razimage(image);
  lsetthickframe(image, width, NDG_MAX);

  writeimage(image, (char *)boost::get<1>(argv).c_str());
  
  endCompute(this);
  exec();
}

#include "pinkFrame.moc"