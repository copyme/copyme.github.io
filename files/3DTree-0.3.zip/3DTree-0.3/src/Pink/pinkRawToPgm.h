/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    pinkRawToPgm.h

  Copyright (c) ESIEE - Michel Couprie and Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/


#ifndef RAWTOPGM_H
#define RAWTOPGM_H

#include <boost/tuple/tuple.hpp>
#include <QThread>
#include <mccodimage.h>

class pinkRawToPgm : public QThread
{
Q_OBJECT

private:
  boost::tuple<std::string,int,int,int,int,int,int,std::string> &argv;
  FILE *fd;
  index_t rs, cs, ds, N, headersize, i;
  int32_t littleendian, datatype;
  struct xvimage *image;
protected:
    virtual void run();
public:
    pinkRawToPgm(boost::tuple<std::string,int,int,int,int,int,int,std::string> &);
    virtual ~pinkRawToPgm();
signals:
    void endCompute(QThread *);
};

#endif // RAWTOPGM_H
