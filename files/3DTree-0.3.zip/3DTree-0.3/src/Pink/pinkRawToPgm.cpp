/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    pinkRawToPgm.cpp

  Copyright (c) ESIEE - Michel Couprie Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/


#include "pinkRawToPgm.h"
#include <stdio.h>
#include <stdint.h>
#include <sys/types.h>
#include <stdlib.h>
#include <assert.h>
#include <mcimage.h>
#include <mcutil.h>
#include <boost/filesystem.hpp> 

pinkRawToPgm::pinkRawToPgm(boost::tuple<std::string,int,int,int,int,int,int,std::string> &p_argv) : argv(p_argv)
{  
  fd = NULL;
  image = NULL;
  rs = boost::get<1>(argv);
  cs = boost::get<2>(argv);
  ds = boost::get<3>(argv);
  N = rs * cs * ds;
  headersize = boost::get<4>(argv);
  datatype = boost::get<5>(argv);
  littleendian = boost::get<6>(argv);
}
pinkRawToPgm::~pinkRawToPgm()
{
  freeimage(image);
  this->quit();
  this->wait();
}

void pinkRawToPgm::run()
{ 
  boost::filesystem::wpath file0(boost::get<7>(argv));

  if(boost::filesystem::exists(file0))
     boost::filesystem::remove(file0);
#ifdef __unix
  fd = fopen(boost::get<0>(argv).c_str(),"r");
#endif
#ifdef WINNT
  fd = fopen(boost::get<0>(argv).c_str(),"rb");
#endif
  
  if (fd == NULL)
  {
    fprintf(stderr,"fopen failed for %s\n", boost::get<0>(argv).c_str());
    exit(1);
  }

  if ((datatype != 1) && (datatype != 2) && (datatype != 4) && (datatype != 5))
  {
    fprintf(stderr, "%s: bad value for pix size: %d\n", boost::get<0>(argv).c_str(), datatype);
    fprintf(stderr, "usage: %s in.raw rs cs ds headersize datatype littleendian [xdim ydim zdim] out.pgm \n", boost::get<0>(argv).c_str());
    fprintf(stderr, "       datatype: 1 for byte, 2 for short int, 4 for long int, 5 for float\n");
    exit(1);
  }

  if (datatype == 1)
  {
    image = allocimage(NULL, rs, cs, ds, VFF_TYP_1_BYTE);
    if (image == NULL)
    {   fprintf(stderr,"%s : allocimage failed\n", boost::get<0>(argv).c_str());
        exit(1);
    }
    fseek(fd, headersize, SEEK_CUR);
    fread(UCHARDATA(image), sizeof(char), N, fd);
  }
  else if (datatype == 2)
  {
    int32_t * I;
    uint16_t tmp;
    uint8_t tmp1;
    image = allocimage(NULL, rs, cs, ds, VFF_TYP_4_BYTE);
    if (image == NULL)
    {   fprintf(stderr,"%s : allocimage failed\n", boost::get<0>(argv).c_str());
        exit(1);
    }
    fseek(fd, headersize, SEEK_CUR);
    I = SLONGDATA(image);
    for (i = 0; i < N; i++) 
    { 
      fread(&tmp, 2 * sizeof(char), 1, fd);
      if (littleendian)
      {
        tmp1 = tmp & 0x00ff;
        tmp = tmp >> 8;
        tmp = tmp | (((uint32_t)tmp1) << 8);      
      }
      I[i] = (int32_t)tmp; 
    }
  }
  else if (datatype == 4)
  {
    image = allocimage(NULL, rs, cs, ds, VFF_TYP_4_BYTE);
    if (image == NULL)
    {   fprintf(stderr,"%s : allocimage failed\n", boost::get<0>(argv).c_str());
        exit(1);
    }
    fseek(fd, headersize, SEEK_CUR);
    if (littleendian)
    {
      int32_t * I;
      uint32_t tmp;
      uint8_t tmp1, tmp2, tmp3;
      I = SLONGDATA(image);
      for (i = 0; i < N; i++) 
      { 
	fread(&tmp, 4 * sizeof(char), 1, fd);
        tmp1 = tmp & 0xff; tmp = tmp >> 8;
        tmp2 = tmp & 0xff; tmp = tmp >> 8;
        tmp3 = tmp & 0xff; tmp = tmp >> 8;
        tmp = tmp | (((uint32_t)tmp3) << 8);
        tmp = tmp | (((uint32_t)tmp2) << 16);
        tmp = tmp | (((uint32_t)tmp1) << 24);      
      }
      I[i] = (int32_t)tmp; 
    }
    else
    {
      fread(SLONGDATA(image), sizeof(float), N, fd);
    }
  }
  else if (datatype == 5)
  {
    image = allocimage(NULL, rs, cs, ds, VFF_TYP_FLOAT);
    if (image == NULL)
    {   fprintf(stderr,"%s : allocimage failed\n", boost::get<0>(argv).c_str());
        exit(1);
    }
    fseek(fd, headersize, SEEK_CUR);
    if (littleendian)
    {
      float *I;
      uint32_t tmp;
      uint8_t tmp1, tmp2, tmp3;
      I = FLOATDATA(image);
      assert(sizeof(uint32_t) == sizeof(float));
      for (i = 0; i < N; i++) 
      { 
	fread(&tmp, sizeof(uint32_t), 1, fd);
        tmp1 = tmp & 0xff; tmp = tmp >> 8;
        tmp2 = tmp & 0xff; tmp = tmp >> 8;
        tmp3 = tmp & 0xff; tmp = tmp >> 8;
        tmp = tmp | (((uint32_t)tmp3) << 8);
        tmp = tmp | (((uint32_t)tmp2) << 16);
        tmp = tmp | (((uint32_t)tmp1) << 24);      
        I[i] = *((float *)(&tmp)); 
      }
    }
    else
    {
      fread(FLOATDATA(image), sizeof(float), N, fd);
    }
  }

  writeimage(image, (char *)boost::get<7>(argv).c_str());
  fclose(fd);
  
  endCompute(this);
  exec();
}
#include "pinkRawToPgm.moc"
