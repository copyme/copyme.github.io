/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    pinkEden.cpp

  Copyright (c) ESIEE - Hugues Talbot and Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/


#include "pinkEden.h"
#include <mcimage.h>
#include <leden.h>


pinkEden::pinkEden(const boost::tuple<std::string,long long unsigned int,int, int, int, std::string, vtkImageData *> &p_argv) : argv(p_argv)
{
  image1 = readimage(boost::get<0>(argv).c_str()); 
  
  if (image1 == NULL)
  {
    fprintf(stderr, "%s: readimage failed\n", boost::get<0>(argv).c_str());
    exit(1);
  }    
 
  rawTree = boost::get<6>(argv);
  In = UCHARDATA(image1);
  grow = boost::get<2>(argv);
  shrink = boost::get<3>(argv);
  topo = boost::get<4>(argv);

  rs = rowsize(image1);
  cs = colsize(image1);
  ds = depth(image1);
}
pinkEden::~pinkEden()
{
  freeimage(image1);
  this->quit();
  this->wait();
}

void pinkEden::VoxCounter()
{
    if(rawTree)
    {
        rawTree->GetDimensions(dims);  
        voxCount = 0;
        for (int z = 0; z < dims[2]; z++)
        {
            for (int y = 0; y < dims[1]; y++)
            {
                for (int x = 0; x < dims[0]; x++)
                {
                    if(*( static_cast<unsigned char *>( rawTree->GetScalarPointer(x,y,z) ) ) > 0)
                        voxCount++;
                }
            }
        }
        niter = (voxCount * ((double)boost::get<1>(argv)/(double)100));
    }
    else
        niter = 0;
}


void pinkEden::run()
{
  VoxCounter();
  
  if (!ledengrowth(In, rs, cs, ds, niter, grow, shrink, topo))
  {
    fprintf(stderr, "%s: function ledengrowth failed\n", boost::get<0>(argv).c_str());
    exit(1);
  }

  writeimage(image1,(char *)boost::get<5>(argv).c_str());
  
  endCompute(this);
  exec();
}

#include "pinkEden.moc"
