/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    pinkSub.cpp

  Copyright (c) ESIEE - Michel Couprie and and Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/


#include "pinkSub.h"
#include <stdio.h>
#include <stdint.h>
#include <sys/types.h>
#include <stdlib.h>
#include <mcimage.h>
#include <larith.h>

pinkSub::pinkSub(boost::tuple<std::string, std::string, std::string> &p_argv): argv(p_argv)
{
  image1 = readimage(boost::get<0>(argv).c_str());
  image2 = readimage(boost::get<1>(argv).c_str());
}

pinkSub::~pinkSub()
{
  freeimage(image1);
  freeimage(image2);
  this->quit();
  this->wait();
}

void pinkSub::run()
{
  if ((image1 == NULL) || (image2 == NULL))
  {
    fprintf(stderr, "sub: readimage failed\n");
    exit(1);
  }
  
  if (!convertgen(&image1, &image2))
  {
    fprintf(stderr, "%s: function convertgen failed\n", boost::get<0>(argv).c_str());
    exit(1);
  }
  
  if (!lsub(image1, image2))
  {
    fprintf(stderr, "sub: function lsub failed\n");
    exit(1);
  }

  writeimage(image1, (char *)boost::get<2>(argv).c_str());
  
  endCompute(this);
  exec();
}

#include "pinkSub.moc"