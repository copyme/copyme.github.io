/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    pinkSeuil.h

  Copyright (c) ESIEE - Kacper Pluta <kacperp@wsinf.edu.pl> and Pink Team
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef SEUIL_H
#define SEUIL_H
#include <mccodimage.h>

#include <QThread>
#include "boost/tuple/tuple.hpp"

class pinkSeuil : public QThread
{
Q_OBJECT
private:
  double seuil;
  struct xvimage * image;
  struct xvimage * imagebin;
  index_t rs, cs, ds, N, x;
  uint8_t *F;
  const boost::tuple<std::string,double,std::string> &argv;
protected:
   void Update();
   virtual void run();
public:
    pinkSeuil(const boost::tuple<std::string,double,std::string> &);
    virtual ~pinkSeuil();
signals:
  QThread *endCompute(QThread *);
};

#endif // SEUIL_H
