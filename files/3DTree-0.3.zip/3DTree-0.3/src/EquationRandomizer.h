#ifndef EQUATIONRANDOMIZER_H
#define EQUATIONRANDOMIZER_H

#include "boost/tuple/tuple.hpp"

class EquationRandomizer
{
private:
    static int equation;
public:
    EquationRandomizer();
    void SearchAnotherEquation();
    boost::tuple<double, double> GetValue(double rS, unsigned int nCyc, int nV, int i);
};

#endif // EQUATIONRANDOMIZER_H
