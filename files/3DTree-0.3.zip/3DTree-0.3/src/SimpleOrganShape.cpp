/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    SimpleOrganShape.cpp
  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include <cmath>
#include <vtkObjectFactory.h>
#include "SimpleOrganShape.h"

vtkStandardNewMacro(SimpleOrganShape);

SimpleOrganShape::SimpleOrganShape()
{
  imlFunction = vtkSampleFunction::New();
  shapeContour = vtkContourFilter::New();
}

double SimpleOrganShape::EvaluateFunction(double x[3])
{
  //Surface equation
   return (2 * pow(15,-3)*(pow((pow(x[0],2) + pow((1.5*x[1]),2)),2)))/x[2];
}

void SimpleOrganShape::Evaluate()
{
  imlFunction->SetImplicitFunction(this);
  // NIE MODUFIKUJ TYCH WARTOŚCI
  imlFunction->SetModelBounds(-20, 20, -20, 20, 0, 30);
  imlFunction->CappingOn();
  
  /* Klasa vtkImplicitFunction domyślnie tworzy na wyjściu
   * obiekt klasy vtkImageData. W celu uzyskania danych vtkPolyData
   * użyto konturyzacji obrazu.*/
  shapeContour->SetInputConnection(imlFunction->GetOutputPort());
  shapeContour->GenerateValues(1, 1, 1);
  shapeContour->Update();
  
  //! Na bazie konturu dokonywana jest inicjalizacja danych klasy BasicObject
  BasicObject::SetPipeline(shapeContour);
}
