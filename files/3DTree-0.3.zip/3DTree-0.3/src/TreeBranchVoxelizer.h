/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    TreeBranchVoxelizer.h

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

/** @brief Klasa ta konwertuje model powierzchniowy do objętościowego.
 * 
 * Konwersja przeprowadzana jest gałąź po gałęzi z zastosowaniem wielowątkowości.
 */

#ifndef TREEBRANCHVOXELIZER_H
#define TREEBRANCHVOXELIZER_H

#include <boost/bind.hpp>
#include <boost/thread.hpp>
#include <boost/shared_ptr.hpp>
#include <vtkImageData.h>
#include "Branch.h"
#include <list>
#include <vtkPolyDataToImageStencil.h>
#include <vtkImageStencil.h>

class TreeBranchVoxelizer
{
protected:
  vtkImageData *rawTree;
  vtkImageData *whiteImage;
  boost::thread_group t_group;
  boost::mutex mutex;
  //dodanie marginesow obrazu - miejsce dla generowania szumow
  const static float IMG_MARGIN = 10.0;
  const static unsigned char BACKGROUND_VAL = 0;
  std::list<boost::shared_ptr<Branch> > &BranchList;
  
  /** Wskaznik na wspólny dla wszystkich wątków iterator.
   * Iterator tworzony/ jest i przypisywany do poczatku listy
   * w metodzie Start(). Po zakończeniu konwersji jest w metodzie Start()
   * niszczony
   */
  std::list<boost::shared_ptr<Branch> >::iterator *ListIterator;
  boost::shared_ptr<Branch> actualConvertBranch;
  double bounds[6];
  int dim[3];
  double origin[3];
  
  double bounds2[6];
  int dim2[3];
  double origin2[3];  
  
  
  float spacing;
  vtkPolyDataToImageStencil *pol2stenc;
  vtkImageStencil *imgstenc;
  //!obraz pomocniczy - kasowany po zakończeniu generowania przez metodę Generate()
  vtkImageData *tmpIMG;
  //! Zarzadza konwersją kolejnych gałęzi
  virtual void Generate();
  //!Konwerter
  virtual void Convert();
  //!Oblicza granice w ktorych zawiera sie obiekt
  void SetBounds();
  TreeBranchVoxelizer(const TreeBranchVoxelizer &);
  void NewWhiteImage(unsigned char);
  
public:
    TreeBranchVoxelizer(std::list<boost::shared_ptr<Branch> > &p_list,float p_spacing = 0.5);
    //! Uruchamia konwersję obrazu. Jesli to konieczne tworzone sa dodatkowe watki.
    virtual void Start();
    virtual vtkImageData *GetRawImage() const {return rawTree;}
    //! Ustawienie spacingu dla całego obrazu.
    virtual ~TreeBranchVoxelizer();
};
#endif // TREEBRANCHVOXELIZER_H
