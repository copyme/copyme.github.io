#ifndef IMAGETYPECONVERTER_H
#define IMAGETYPECONVERTER_H

#include <vtkImageData.h>
#include <vtkSmartPointer.h>
#include <mccodimage.h>

class ImageTypeConverter
{
public:
    //! Konwersja dokonywana za pomocą klasy itk::ImportImageFilter
    static vtkSmartPointer< vtkImageData > PinkToVTK(const xvimage * pinkImage , double *origin);
    //! @return Wskaźnik do utworzonej za pomocą operatora new struktury xvimage
    static xvimage * const VTKToPink( vtkImageData * );
};

#endif // IMAGETYPECONVERTER_H
