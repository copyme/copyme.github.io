/*
    <one line to give the program's name and a brief idea of what it does.>
    Copyright (C) 2011  Kacper Pluta <kacperp@wsinf.edu.pl>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/


#ifndef TREEBRANCHPRODUCER_H
#define TREEBRANCHPRODUCER_H

#include <list>
#include "Branch.h"
#include <vtkPlane.h>

#include <boost/bind.hpp>
#include <boost/thread.hpp>
#include <vtkClipPolyData.h>
#include <vtkAppendPolyData.h>
#include "CollisionDetection.h"
#include "SpaceDivision.h"
#include <vtkCleanPolyData.h>

class TreeBranchProducer
{
private:
  bool flag;
  boost::thread_group t_group;
  boost::mutex mutex;
  bool threads;
  int rate;
  double normal[3];
  double angle[2];
  double diameter[2];
  double length[2];
  float minFlowRatio;
  double volumeTmp[2];
  float Distance2Length;
  float r,rl,rr;
  vtkPolyData *ChildRegions[4];
  CollisionDetector *detector;
  SpaceDivision *divisorOfSpace;
  vtkCleanPolyData *polyCleaner;
  vtkClipPolyData *clipper;
  vtkAppendPolyData *appendPoly;
  boost::shared_ptr<Branch>  Patella;
  vtkPlane *cutPlane;
  std::list<boost::shared_ptr<Branch> > &BranchList;
  boost::shared_ptr<Branch> root;
  
  void SplitRegion(boost::shared_ptr< Branch > branch);
  void ComputeCutPlane(boost::shared_ptr<Branch>, float degrees = 90.0);
  void SetBranchingAngle();
  void SetFlowRatio();
  inline void SetPatella(double len = 0.001)
  {
    Patella.reset();
    Patella = Branch::New(root->GetRadius(),len, root->GetTransform(),2,TWIST_OFF);
  }
  inline void SetPatella(double len, double diameter)
  {
    Patella.reset();
    Patella = Branch::New(diameter/2.0,len, root->GetTransform(),2,TWIST_OFF);
  }
  void SetChildDiameters();
  void SetChildLength();
  double ComputeCenterOfVolume(double step, float precision, vtkPolyData *region, double branchLenght);
  void TranslateNewBranches(boost::shared_ptr<Branch>, boost::shared_ptr<Branch>);
  void Generate(boost::shared_ptr<Branch>);
  void GoToNextRecursion(boost::shared_ptr<Branch>, boost::shared_ptr<Branch>);
  /*!
  * Reguła ta dokonuje korekcji kątu rozwidlenia jeśli warotść bezwzględna
  * różnicy kątów dzieci jest większa od 10 stponi należy dokonać korekcji.
  * Korekjca polega na zaczepieniu na końcu rodzica płaszczyzny podziału 
  * objętości regionu i skierowanie tej płaszczyny w kierunku siecznej kątu
  * rozwidlenia.
  * 
  */
  //! Kasuje regiony wykorzystane do testu kolizji
  void RemovePunkRegions();
  void Rule4a();
  int Rule6a();
  void Rule7a();
public:
  void Start();
  TreeBranchProducer(std::list<boost::shared_ptr<Branch> > &p_list, boost::shared_ptr<Branch> p_masterRoot, int p_rate,  bool p_threads = false);
  ~TreeBranchProducer();
};

#endif // TREEBRANCHPRODUCER_H
