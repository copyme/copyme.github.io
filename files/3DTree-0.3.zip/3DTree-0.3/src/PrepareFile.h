/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    PrepareFile.h
  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/** @brief Klasa ta pozwala dokonać konwersji binarnego obrazu do obrazu "kolorowego". 
 * 
 * Konwersja dokonywana jest poprzez zdefiniowanie tła oraz przedziału, z którego 
 * następnie dokonywane jest losowanie wartości wokseli obiektu - drzewa.
*/

#ifndef PREPAREFILE_H
#define PREPAREFILE_H

#include <QtCore/QThread>
#include "boost/tuple/tuple.hpp"
#include <vtkImageData.h>
#include <vtkMetaImageWriter.h>

class PrepareFile : public QThread
{
Q_OBJECT
private:
  vtkMetaImageWriter *mhdWriter;
  boost::tuple<vtkImageData *, int, int, int, std::string> &argv;
  int dims[3];
  vtkImageData *rawTree;
  vtkImageData *whiteImage;
  int l, r;
  double b;
protected:
    virtual void run();
public:
    PrepareFile(boost::tuple<vtkImageData *, int, int, int, std::string> &);
    virtual ~PrepareFile();
signals:
  QThread *endCompute(QThread *);
    
};

#endif // PREPAREFILE_H
