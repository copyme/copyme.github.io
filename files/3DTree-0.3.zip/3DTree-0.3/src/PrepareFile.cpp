/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    PrepareFile.cpp
  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/


#include "PrepareFile.h"
#include <cstdlib>
#include <ctime>


PrepareFile::PrepareFile(boost::tuples::tuple<vtkImageData *, int, int, int, std::string >& p_argv) : argv(p_argv)
{
  mhdWriter = vtkMetaImageWriter::New();
  mhdWriter->SetCompression(0);
  mhdWriter->SetFileName(boost::get<4>(argv).c_str());
  
  rawTree = boost::get<0>(argv);
  
  whiteImage = vtkImageData::New();
  whiteImage->SetSpacing(rawTree->GetSpacing());
  whiteImage->SetDimensions(rawTree->GetDimensions());
  whiteImage->SetExtent(rawTree->GetExtent());
  whiteImage->SetOrigin(rawTree->GetOrigin());
  whiteImage->SetScalarTypeToShort();
  whiteImage->AllocateScalars();
  
  b = boost::get<1>(argv);
  l = boost::get<2>(argv);
  r = boost::get<3>(argv);
  
  srand(time(0));
}

void PrepareFile::run()
{
  if(rawTree)
  {
    rawTree->GetDimensions(dims);  
    for (int z = 0; z < dims[2]; z++)
    {
      for (int y = 0; y < dims[1]; y++)
      {
	for (int x = 0; x < dims[0]; x++)
	{
	  if(rawTree->GetScalarComponentAsDouble(x,y,z,0) > 0)
	  {
	    if(l < r)
	      whiteImage->SetScalarComponentFromDouble(x,y,z,0,rand() % (r - l + 1) + l);
	    else
	      whiteImage->SetScalarComponentFromDouble(x,y,z,0,rand() % (l - r + 1) + r);
	  }
	  else
	    whiteImage->SetScalarComponentFromDouble(x,y,z,0,b);
	}
      }
    }
  }
  mhdWriter->SetInput(whiteImage);
  mhdWriter->Write();
  mhdWriter->Update();
  
  endCompute(this);
  exec();
}

PrepareFile::~PrepareFile()
{
  mhdWriter->Delete();
  whiteImage->Delete();
  this->quit();
  this->wait();
}

#include "PrepareFile.moc"