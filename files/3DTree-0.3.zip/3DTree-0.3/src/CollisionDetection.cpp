/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    CollisionDetection.cpp

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "CollisionDetection.h"
#include <vtkCollisionDetectionFilter.h>

CollisionDetector::CollisionDetector()
{ 
  transform0 = vtkTransform::New();
  transform1 = vtkTransform::New();
  collider = vtkCollisionDetectionFilter::New();
  collider->ReleaseDataFlagOn();
}
int CollisionDetector::CollisionDetection(vtkPolyData* region, boost::shared_ptr< Branch > owner)
{
   RemoveAllInputs();
   
   collider->SetInputConnection(0, owner->GetOutputPort());
   collider->SetTransform(0, transform0);
   collider->SetInput(1, region);
   collider->SetTransform(1, transform1);
   collider->SetBoxTolerance(0.0);
   collider->SetCellTolerance(0.0);
   collider->SetNumberOfCellsPerNode(2);
   collider->SetCollisionModeToAllContacts();
   collider->GenerateScalarsOn();
   collider->Update();
   
   return collider->GetNumberOfContacts();
}

CollisionDetector::~CollisionDetector()
{
   collider->Delete();
   transform0->Delete();
   transform1->Delete();
}

void CollisionDetector::RemoveAllInputs()
{
  collider->RemoveAllInputs();
}
