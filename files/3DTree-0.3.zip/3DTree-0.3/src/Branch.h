/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    Branch.h
  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

/** @brief Klasa implementuje pojedynczą gałąź.
 * 
 * Klasa te opisuje pojedynczą gałąź w raz z odpowiadającym jej regionem
 * płuca.
 */


#ifndef BRANCH_H
#define BRANCH_H

#include <boost/shared_ptr.hpp>
#include "BasicObject.h"
#include <vtkPolyData.h>
#include <vtkTubeFilter.h>
#include <vtkCellArray.h>
#include <vtkTriangleFilter.h>

enum twisting {TWIST_ON, TWIST_OFF};
class Branch : public BasicObject
{
private:
    bool isEndBranch;
    vtkPolyData *branchRegion;
    vtkTubeFilter *tubeFilter;
    int nV;      // Ilość punktów
    double vX, vY, vZ, h;
    int equation;
    double rS;             // Promień spirali
    unsigned int nCyc; 
    vtkPoints *points;
    vtkCellArray *lines;
    vtkPolyData *polyData;
    //Zastosowanie filtru na gałęzi naprawia test kolizji
    vtkTriangleFilter *triFilter;
    
public:
    //! Tworzy nową gałąź i zwraca do niej wskaźnik.
    static boost::shared_ptr<Branch> New(double r, double p_h, twisting p_twist = TWIST_ON);
    static boost::shared_ptr<Branch> New(double r, double p_h, vtkTransform *relativeTrans, int rootEQ, twisting p_twist = TWIST_ON);
    //! Dodaje do gałęzi odpowiadający jej region płuca. Zobacz @ref SpaceDivisionAlgorithm.h
    void AddRegion(vtkPolyData *t_Region){branchRegion->DeepCopy(t_Region);}
    //! Zwraca region płuca należący do gałęzi.
    vtkPolyData *GetRegion() const {return branchRegion;}
    //! Kasuje region płuca należący do gałęzi.
    void RemoveRegion();
    //! @return Śrdnicę gałęzi.
    virtual double GetDiameter() const {return tubeFilter->GetRadius()*2.0;}
    //! @return Wysokość gałęzi.
    int GetEQ() const {return equation;}
    virtual double GetHeight() const {return h;}
    //! @return Promień gałęzi.
    virtual double GetRadius() const {return tubeFilter->GetRadius();}
    virtual void ChangeRadiusWithoutEffect(double r)
    {
      tubeFilter->SetRadius(r);  
      triFilter->Update();
      this->Update();
    }

    //! @return Wskaźni na wartości centralne odpowiednio dla osi X,Y,Z.
    virtual double* GetCenter() const {return GetOutput()->GetCenter();}  
    virtual ~Branch();
    void SetIsEnd(){ isEndBranch = true; }
    bool GetIsEnd() const { return isEndBranch; }
protected:
    Branch(double r, double p_h, twisting p_twist);
    Branch(double r, double p_h, vtkTransform *relativeTrans, int rootEQ, twisting p_twist);
};

#endif // BRANCH_H
