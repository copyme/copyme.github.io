/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    SpaceDivision.h

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

/**
 * 
 */

#ifndef SPACEDIVISION_H
#define SPACEDIVISION_H

#include <vtkClipPolyData.h>
#include <vtkCutter.h>
#include <vtkStripper.h>
#include <vtkPlane.h>
#include <vtkPolyData.h>
#include <vtkTriangleFilter.h>
#include <vtkDensifyPolyData.h>
#include <vtkAppendPolyData.h>
#include <vtkFeatureEdges.h>
 
class SpaceDivision
{
private:
  //! Pozwala na przeciecie obiektu;
  vtkClipPolyData *clipper;
  
  /** Pozwala na wyciagniecie krawedzi obiektu w miejscu przeciecia
   * co pozwala wygenerowac nowa sciane w miejscu przeciecia.
   */
  vtkFeatureEdges *boundaryEdges;
  //! Generuje trójkątne paski - nowa ściana
  vtkStripper *cutStrips;
  //! Łączy nowy region z wygenerowaną ścianą.
  vtkAppendPolyData *newRegion;
  //! Poprawia jakość wygenerowanej ściany poprzez zwiększenie gęstości danych
  vtkDensifyPolyData *fixNewWall;
  //! Koryguje dane wygenerowane przez fixNewWall
  vtkTriangleFilter *improveNewWall;
  /** 
   * Kasuje wejścia z filtrów co umożliwia wykorzystanie filtrów do wygenerowania
   * nowych danych 
   */
public:
  SpaceDivision();
  void RemoveAllInputs();
  virtual ~SpaceDivision();
  /**
   * Metoda ta pobiera płaszczyznę, która dzieli powierzchnie - region na dwie części
   * nowe częsci zapisywane są w ostatnim parametrze - tablicy wskażników na vtkPolyData.
   * Tablica ta powinna mieć rozmiar 4 gdyż oprócz regionu zapisywana jest jego maska - region
   * nie posiadający ściany w miejscu przecięcia.
   */
  vtkPolyData * AddBoundary(vtkPolyData *);
  void ClipBoundaries(vtkPlane *plane, vtkPolyData *surfaces, vtkPolyData **);
};

#endif // SPACEDIVISION