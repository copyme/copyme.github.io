/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    CalculateVolumeDividingRatio.cpp

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

//Więcej informacji znajduje się w CalculateVolumeDividingRatio.cpp

#include "CalculateVolumeDividingRatio.h"
#include <cmath>
#include <vtkMath.h>
#include <vtkPolyDataMapper.h>

float CalculateVolumeDividingRatio(vtkPolyData* parentRegion, vtkPolyData* childRegion)
{
  float p1[3] = {*(parentRegion->GetBounds()),*(parentRegion->GetBounds()+2),*(parentRegion->GetBounds()+4)};
  float p2[3] = {*(parentRegion->GetBounds()+1),*(parentRegion->GetBounds()+2),*(parentRegion->GetBounds()+4)};
    
  //Szerokość
  float whd[3];
  whd[0] = sqrt(vtkMath::Distance2BetweenPoints(p1, p2));
    
  p1[0] = *(parentRegion->GetBounds());
  p1[1] = *(parentRegion->GetBounds()+2);
  p1[2] = *(parentRegion->GetBounds()+4);
    
  p2[0] = *(parentRegion->GetBounds());
  p2[1] = *(parentRegion->GetBounds()+3);
  p2[2] = *(parentRegion->GetBounds()+4);
    
  //Wysokość
  whd[1] = sqrt(vtkMath::Distance2BetweenPoints(p1, p2));
    
  p1[0] = *(parentRegion->GetBounds());
  p1[1] = *(parentRegion->GetBounds()+2);
  p1[2] = *(parentRegion->GetBounds()+4);
    
  p2[0] = *(parentRegion->GetBounds());
  p2[1] = *(parentRegion->GetBounds()+2);
  p2[2] = *(parentRegion->GetBounds()+5);
    
  //Długość
  whd[2] = sqrt(vtkMath::Distance2BetweenPoints(p1, p2));
    
  float volume1 = whd[0] * whd[1] * whd[2];
  float volume2 = whd[0]/20 * whd[1]/20 * whd[2]/20;
     
  //Stosunek mniejszego 20 razy prostopadłościanu w większym
  float parentRegion_ratio = volume1 / volume2;
  
  p1[0] = *(childRegion->GetBounds());
  p1[1] = *(childRegion->GetBounds()+2);
  p1[2] = *(childRegion->GetBounds()+4);
    
  p2[0] = *(childRegion->GetBounds()+1);
  p2[1] = *(childRegion->GetBounds()+2);
  p2[2] = *(childRegion->GetBounds()+4);
    
  //Szerokość
  whd[0] = sqrt(vtkMath::Distance2BetweenPoints(p1, p2));
    
  p1[0] = *(childRegion->GetBounds());
  p1[1] = *(childRegion->GetBounds()+2);
  p1[2] = *(childRegion->GetBounds()+4);
    
  p2[0] = *(childRegion->GetBounds());
  p2[1] = *(childRegion->GetBounds()+3);
  p2[2] = *(childRegion->GetBounds()+4);
    
  //Wysokość
  whd[1] = sqrt(vtkMath::Distance2BetweenPoints(p1, p2));
    
  p1[0] = *(childRegion->GetBounds());
  p1[1] = *(childRegion->GetBounds()+2);
  p1[2] = *(childRegion->GetBounds()+4);
    
  p2[0] = *(childRegion->GetBounds());
  p2[1] = *(childRegion->GetBounds()+2);
  p2[2] = *(childRegion->GetBounds()+5);
    
  //Długość
  whd[2] = sqrt(vtkMath::Distance2BetweenPoints(p1, p2));
  
  volume1 = whd[0] * whd[1] * whd[2];
  
  //Stosunek mniejszego 20 razy prostopadłościanu w większym
  float childRegion_ratio = volume1/volume2;
  //Stosunek mniejszych prostopadłościanów dziecka do rodzica
  float r = childRegion_ratio/parentRegion_ratio;
  
  return r;

}
    