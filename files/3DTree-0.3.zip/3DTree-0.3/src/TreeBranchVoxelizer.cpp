/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    TreeBranchVoxelizer.cpp

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
//For more info please take a look at TreeBranchVoxelizer.h

#include "TreeBranchVoxelizer.h"
#include "AlgorithmConstData.h"
#include <vtkAppendPolyData.h>
#include <vtkPolyDataMapper.h>
#include <vtkPointData.h>
#include <cmath>
#include <cassert>
#include <mcimage.h>
#include <ldist.h>
#include <vtkPolyDataWriter.h>
#include "ImageTypeConverter.h"

TreeBranchVoxelizer::TreeBranchVoxelizer(std::list<boost::shared_ptr<Branch> > &p_list,float p_spacing) : BranchList(p_list)
{
  spacing = p_spacing;
  ListIterator = NULL;
  tmpIMG = NULL;
  
  SetBounds();
  //Wyliczenie wymiarow obrazu
  for (int i = 0; i < 3; i++)
  {
    dim[i] = static_cast<int>(ceil((bounds[i * 2 + 1] - bounds[i * 2]) / spacing));
  }
  
  origin[0] = bounds[0];
  origin[1] = bounds[2];
  origin[2] = bounds[4];
  
  pol2stenc = vtkPolyDataToImageStencil::New();
  pol2stenc->ReleaseDataFlagOn();
  
  imgstenc = vtkImageStencil::New();
  imgstenc->ReleaseDataFlagOn();
  
  //Inicjalizacja pierwszej "klatki"
  NewWhiteImage(BACKGROUND_VAL);
  rawTree = whiteImage;
  
}
//Konstruktor dla obiektow, ktore beda uruchamiane na watkach
TreeBranchVoxelizer::TreeBranchVoxelizer(const TreeBranchVoxelizer & copyFromMe) : BranchList(copyFromMe.BranchList)
{
  rawTree = copyFromMe.rawTree;
  ListIterator = copyFromMe.ListIterator;
  tmpIMG = NULL;
  
  for(int i = 0;i< 6;i++)
  {
    bounds[i] = copyFromMe.bounds[i];
  }
  
  for(int i = 0;i< 3;i++)
  {
    dim[i] = copyFromMe.dim[i];
  }
  
  for(int i = 0;i< 3;i++)
  {
    origin[i] = copyFromMe.origin[i];
  }
  
  spacing = copyFromMe.spacing;
  
  pol2stenc = vtkPolyDataToImageStencil::New();
  pol2stenc->ReleaseDataFlagOn();
  
  imgstenc = vtkImageStencil::New();
  imgstenc->ReleaseDataFlagOn();
}


void TreeBranchVoxelizer::SetBounds()
{
  vtkAppendPolyData *appendTree = vtkAppendPolyData::New();
  std::list<boost::shared_ptr<Branch> >::iterator branchListIterator;
  
  branchListIterator = BranchList.begin();
  
  while(branchListIterator != BranchList.end())
  {
    appendTree->AddInput(branchListIterator->get()->GetOutput());
    *branchListIterator++;
  }
  
  appendTree->Update();
  
//  vtkPolyDataWriter *objW = vtkPolyDataWriter::New();
//  objW->SetFileName("treeobj.polydata");
//  objW->SetFileTypeToBinary();
//  objW->SetInput(appendTree->GetOutput());
//  objW->Write();
//  objW->Update();
  
//  exit(1);
  
  vtkPolyDataMapper *polyMapper = vtkPolyDataMapper::New();
  
  //Mapowanie geometrii w celu uzyskania wymiarów
  polyMapper->SetInputConnection(appendTree->GetOutputPort());
  polyMapper->Update();
  
  polyMapper->GetBounds(bounds);
  
  //Dodanie marginesu od strony mniejszych wartości - dla wartosci wiekszych patrz SetExtent - whiteImage
  bounds[0] -= IMG_MARGIN;
  bounds[2] -= IMG_MARGIN;
  bounds[4] -= IMG_MARGIN;
  
  appendTree->Delete();
  polyMapper->Delete();
}

void TreeBranchVoxelizer::NewWhiteImage(unsigned char ival)
{
  whiteImage = vtkImageData::New();
  whiteImage->SetSpacing(spacing,spacing,spacing);
  whiteImage->SetExtent(0, dim[0] + IMG_MARGIN, 0, dim[1] + IMG_MARGIN, 0, dim[2] + IMG_MARGIN);
  
  whiteImage->SetOrigin(origin);
  whiteImage->SetScalarTypeToUnsignedChar();
  whiteImage->AllocateScalars();
  
  vtkIdType count = whiteImage->GetNumberOfPoints();
  
  for (vtkIdType i = 0; i < count; ++i)
  {
    whiteImage->GetPointData()->GetScalars()->SetTuple1(i, ival);
  }
}

TreeBranchVoxelizer::~TreeBranchVoxelizer()
{
  imgstenc->Delete();
  pol2stenc->Delete();
}

void TreeBranchVoxelizer::Convert()
{
    assert((unsigned char)round(actualConvertBranch->GetDiameter()));
    
    actualConvertBranch->GetOutput()->GetBounds(bounds2);
    
    
    bounds2[0] -= IMG_MARGIN;
    bounds2[2] -= IMG_MARGIN;
    bounds2[4] -= IMG_MARGIN;
    
    for (int i = 0; i < 3; i++)
    {
      dim2[i] = static_cast<int>(ceil((bounds2[i * 2 + 1] - bounds2[i * 2]) / spacing));
    }
    origin2[0] = bounds2[0];
    origin2[1] = bounds2[2];
    origin2[2] = bounds2[4];       

//    NewWhiteImage((unsigned char)round(actualConvertBranch->GetDiameter()));
    
    whiteImage = vtkImageData::New();
    whiteImage->SetSpacing(spacing,spacing,spacing);
    whiteImage->SetExtent(0, dim2[0] + IMG_MARGIN, 0, dim2[1] + IMG_MARGIN, 0, dim2[2] + IMG_MARGIN);
    
    whiteImage->SetOrigin(origin2);
    whiteImage->SetScalarTypeToUnsignedChar();
    whiteImage->AllocateScalars();
    
    vtkIdType count = whiteImage->GetNumberOfPoints();
    
    for(vtkIdType i = 0; i < count; ++i)
    {
      whiteImage->GetPointData()->GetScalars()->SetTuple1(i, (unsigned char)round(actualConvertBranch->GetDiameter()));
    }

    pol2stenc->RemoveAllInputs();
    pol2stenc->SetInput(actualConvertBranch->GetOutput());
    pol2stenc->SetInformationInput(whiteImage);

    imgstenc->RemoveAllInputs();
    imgstenc->SetInput(whiteImage);
    imgstenc->SetStencil(pol2stenc->GetOutput());
    imgstenc->ReverseStencilOff();
    imgstenc->SetBackgroundValue(BACKGROUND_VAL);
    imgstenc->Update();

    tmpIMG = vtkImageData::New();
    xvimage *In = ImageTypeConverter::VTKToPink(imgstenc->GetOutput());
    /** \bug Na łącznikach gałęzi mogą występować otowry
    * -- dzieje się tak z nieznanych przyczyn po ostatnich poprawkach. 
    */
    if (!lcloseball(In, 2, 26))
    {
      fprintf(stderr, "Function lcloseball failed\n");
      exit(1);
    }    
    
    tmpIMG->DeepCopy(ImageTypeConverter::PinkToVTK(In, origin2));

    //Wykasuj niepotrzebne dane
    whiteImage->Delete();
    freeimage(In);
}


void TreeBranchVoxelizer::Generate()
{  

    while(true)
    {
        /*
     * Obiekty z STL nie są bezpieczne podczas użytkowania na wątkach.
     * Dlatego nie usuwamy nic z listy w tym miejscu by nie zmienić jej rozmiaru
     * co do prowadziłoby do wysypania się programu. Iterator wspolny jest dla
     * wszystkich watkow.
     */
        mutex.lock();
        if(*(ListIterator) !=  BranchList.end())
        {
            actualConvertBranch = *(*ListIterator);
            *(*ListIterator)++;
        }
        //zdejmi blokade i zakoncz petle
        else
        {
            mutex.unlock();
            break;
        }
        mutex.unlock();

        Convert();
        
        double offset[3];
        offset[0] = origin[0] > origin2[0] ?  fabs(origin[0] - origin2[0])/spacing : fabs(origin2[0] - origin[0])/spacing;
        offset[1] = origin[1] > origin2[1] ?  fabs(origin[1] - origin2[1])/spacing : fabs(origin2[1] - origin[1])/spacing;
        offset[2] = origin[2] > origin2[2] ?  fabs(origin[2] - origin2[2])/spacing : fabs(origin2[2] - origin[2])/spacing;
        
        int dim2[3];
        tmpIMG->GetDimensions(dim2);
        
        for (register unsigned int z = 0; z < dim2[2]; z++)
        {
            for (register unsigned int y = 0; y < dim2[1]; y++)
            {
                for (register unsigned int x = 0; x < dim2[0]; x++)
                {
                    if( *( static_cast<unsigned char *>( tmpIMG->GetScalarPointer( x, y, z ) ) ) != BACKGROUND_VAL)
                    {
                        *( static_cast<unsigned char *>( rawTree->GetScalarPointer( 
                                                             (x + offset[0]),
                                                             (y + offset[1]),
                                                             (z + offset[2]) ) ) ) = 
                                *( static_cast<unsigned char *>( tmpIMG->GetScalarPointer( x, y, z ) ) );
                    }
                }
            }
        }
        if(tmpIMG != NULL)
        {
            tmpIMG->Delete();
        }
    }
}
/*
 * Metoda uruchamia proces konwersji obiektu w grafice powierzchniowej na obiekt w grafice
 * objetosciowej.
 * Jeśli lista zawiera wiecej elementow niz jeden uruchom konwersje na watkach.
 */
void TreeBranchVoxelizer::Start()
{
  int i;
  //Stworzenie i przypisanie wspólnego dla wszystkich wątków Iteratora;
   ListIterator = new std::list<boost::shared_ptr<Branch> >::iterator;
  *(ListIterator) = BranchList.begin();
  
  if( BranchList.size() == 1)
  {
    Generate();
  }
  else
  {
    if(BranchList.size() >= MAX_THREAD)
    {
      i = MAX_THREAD;
    }
    else
    {
      i = BranchList.size();
    }
    for(; i > 0; i--)
    {
      t_group.create_thread(boost::bind(&TreeBranchVoxelizer::Generate,new TreeBranchVoxelizer(*this)));
    }
    t_group.join_all();
  }
  //Wykaosowanie niepotrzebnego juz iteratora;
  delete ListIterator;
}
