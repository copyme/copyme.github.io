/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    3DTreeGUI.h

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef ThreeDTreeGUI_H
#define ThreeDTreeGUI_H

#include <QAction>
#include <QCheckBox>
#include <QRadioButton>
#include <QtGui/QMainWindow>
#include <QVTKWidget.h>
#include <vtkRenderer.h> 
#include <vtkRenderWindow.h>
#include <QSplitter>
#include <QVBoxLayout>
#include <QLabel>
#include <QTabWidget>
#include <QPushButton>
#include <vtkImageData.h>
#include <QSpinBox>
#include <QToolBox>
#include <QCheckBox>
#include <pinkRawToPgm.h>
#include <pinkEden.h>
#include <pinkSeuil.h>

#include "CompueTree.h"
#include <vtkMetaImageWriter.h>
#include <vtkRenderer.h>
#include <vtkImageCast.h>
#include <vtkMetaImageReader.h>
#include <vtkPolyDataMapper.h>
#include <vtkLODActor.h>
#include <vtkContourFilter.h>
#include <vtkAppendPolyData.h>
#include <pinkFrame.h>
#include <pinkSub.h>
#include <pinkAsft.h>
#include <pinkPgmToRaw.h>
#include <PrepareFile.h>

class ThreeDTreeGUI : public QMainWindow
{
  Q_OBJECT
private:
  QVTKWidget *vtkWidget;     
  vtkRenderer *ren;
  QAction *saveAction;
  QAction *closeAction;
  QList <QAction* > fileMenuBarActions;
  QSplitter *splitter;
  QWidget *leftPanel;
  QVBoxLayout *layout;
  QLabel *label0;
  QWidget *mainTab;
  QWidget *edenTab;
  QTabWidget *tabMenu;
  QLabel *infoBox;
  QSpinBox *mainTabDiameterSpinBox;
  QDoubleSpinBox *mainTabSpacingSpinBox;
  QPushButton *generateButton;
  QPushButton *restartNoiseButton;
  QLabel *mainTablabel1;
  QLabel *mainTablabel0;
  QVBoxLayout *mainTabLayout;
  QVBoxLayout *edenTabLayout;
  QVBoxLayout *noiseTabLayout;
  QWidget *noiseTab;
  QToolBox *noiseBox;
  QCheckBox *edenPlus;
  QCheckBox *edenMinus;
  QLabel *edenPercentLabel;
  QSpinBox *edenPercent;
  QLabel *edenPointConnection;
  QPushButton *addEdenButton;
  
  QRadioButton *edenNeighborhoodConnections0;
  QRadioButton *edenNeighborhoodConnections6;
  QRadioButton *edenNeighborhoodConnections26;
  
  QVBoxLayout *asftTabLayout;
  QWidget *asftTab;
  QLabel *asftRadiusLabel;
  QSpinBox *asftRadius;
  QPushButton *addAsftButton;
  
  QVBoxLayout *bigNoiseTabLayout;
  QWidget *bigNoiseTab;
  QLabel *bigNoiseRadiusLabel;
  QSpinBox *bigNoiseRadius;
  QPushButton *addBigNoiseButton;
  
  
  QWidget *prepareTab;
  QVBoxLayout *prepareTabLayout;
  
  QLabel *backgroundValueLabel;
  QSpinBox *backgroundValue;
  QLabel *intervalLLabel;
  QLabel *intervalRLabel;
  QSpinBox *intervalLValue;
  QSpinBox *intervalRValue;  
  QPushButton *preparePGMButton;
  
  long long unsigned int voxCount;
  
  int dims[3];
  
  ComputeThread *treeThread;
  PrepareFile *prepareThread;
  
  vtkImageData *rawTree;
  vtkContourFilter *treeContour;
  vtkPolyDataMapper *treeMapper;
  vtkLODActor *treeActor;
  vtkMetaImageWriter *metaWriter;
  vtkMetaImageReader *metaReader;
  bool isNoise;
  
  pinkRawToPgm *raw2PgmThread;
  pinkPgmToRaw *pgm2RawThread;
  pinkEden *edenThread;
  pinkSeuil *seuilThread;
  pinkFrame *frameThread;
  pinkSub *subThread;
  pinkAsft *asftThread;
  
private slots:
  void save();
  void printDiameterInfo();
  void printSpacingInfo();
  void generateTree();
  void refresh(QThread *);
  void raw2PgmPink(vtkImageData *p_rawTree, QThread *p);
  void pgm2RawPink(QThread *p);
  void seuilPink(QThread *);
  void framePink(QThread *);
  void subPink(QThread *);
  void removeNoisePink();
  void checkEdenOption();
  void addEden();
  void addAsft();
  void addEdenForBigNoise();
  void terminateThread(QThread *);
  void preparePGMFile();
  void addAsftForBigNoise(QThread *);
public:
    ThreeDTreeGUI();
    virtual ~ThreeDTreeGUI();
};

#endif // ThreeDTreeGUI_H
