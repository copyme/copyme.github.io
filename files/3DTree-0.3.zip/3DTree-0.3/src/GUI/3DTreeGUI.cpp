/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    3DTreeGUI.cpp

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "3DTreeGUI.h"
#include <sstream>
#include <QtGui/QMenuBar>
#include <QFileDialog>
#include <QTextStream>
#include <removeTmp.h>
#include "boost/tuple/tuple.hpp"
#include <boost/shared_ptr.hpp>
#include "AlgorithmConstData.h"
#include "Branch.h"
#include "TreeBranchProducer.h"
#include <vtkProperty.h>
#include <vtkSTLWriter.h>

#if defined(_M_X64) || defined(__amd64__)
#define MIN_DIA 1
#define MIN_SPACING 0.3
#else
#define MIN_DIA 1
#define MIN_SPACING 0.5
#endif

ThreeDTreeGUI::ThreeDTreeGUI()
{ 
  
    this->setMinimumHeight(600);
    this->setMinimumWidth(800);
   
    treeThread = NULL;
    rawTree = NULL;
    treeContour = NULL;
    treeMapper = NULL;
    treeActor = NULL;
    metaReader = NULL;
    metaWriter = NULL;
    seuilThread = NULL;
    edenThread = NULL;
    raw2PgmThread = NULL;
    pgm2RawThread = NULL;
    frameThread = NULL;
    subThread = NULL;
    asftThread = NULL;
    prepareThread = NULL;
    
    isNoise = false;
  
    closeAction = new QAction(trUtf8("&Quit"), this);
    saveAction = new QAction(trUtf8("&Save"), this);
    saveAction->setDisabled(true);
   
    fileMenuBarActions.insert(1,saveAction);
    fileMenuBarActions.insert(1,closeAction);
    
    connect(closeAction, SIGNAL(triggered()), SLOT(close()));
    connect(saveAction, SIGNAL(triggered()), this, SLOT(save()));
    
    menuBar()->addMenu(trUtf8("&File"))->addActions(fileMenuBarActions);
    menuBar()->addMenu(trUtf8("&About"));
    
    vtkWidget = new QVTKWidget(this,QFlag(0));
    ren = vtkRenderer::New();     
    vtkWidget->GetRenderWindow()->AddRenderer(ren);
    vtkWidget->GetRenderWindow()->SetStereoTypeToAnaglyph();
    ren->SetBackground(1.0, 1.0, 1.0);
    ren->Render();

    splitter = new QSplitter;
    splitter->setOrientation(Qt::Horizontal);
    splitter->addWidget(vtkWidget);
    
    leftPanel = new QWidget;
    
    label0 = new QLabel;
    label0->setFrameStyle(QFrame::Box | QFrame::Sunken);
    label0->setText(trUtf8("<b>Settings</b>"));
    label0->setAlignment(Qt::AlignTop | Qt::AlignLeft);
    
    layout = new QVBoxLayout;
    layout->addWidget(label0);
    
    mainTab = new QWidget;
    
    mainTabLayout = new QVBoxLayout;
    mainTabLayout->setAlignment(Qt::AlignTop | Qt::AlignLeft);
    
    mainTablabel0 = new QLabel;
    mainTablabel0->setFrameStyle(QFrame::Box | QFrame::Sunken);
    mainTablabel0->setText(trUtf8("<b>Lowest diameter value:</b>"));
    
    mainTabLayout->addWidget(mainTablabel0);
    
    mainTabDiameterSpinBox = new QSpinBox;
    mainTabDiameterSpinBox->setMaximum(MAX_DIAMETER);
    mainTabDiameterSpinBox->setMinimum(MIN_DIA);
    mainTabDiameterSpinBox->setFixedWidth(70);
    mainTabDiameterSpinBox->setValue(6);
    connect(mainTabDiameterSpinBox,SIGNAL(valueChanged(int)), this, SLOT(printDiameterInfo()));
    
    mainTabLayout->addWidget(mainTabDiameterSpinBox);
    
    mainTablabel1 = new QLabel;
    mainTablabel1->setFrameStyle(QFrame::Box | QFrame::Sunken);
    mainTablabel1->setText(trUtf8("<b>Spacing:</b>"));
    
    mainTabLayout->addWidget(mainTablabel1);
    
    mainTabSpacingSpinBox = new QDoubleSpinBox;
    mainTabSpacingSpinBox->setMaximum(1.0);
    mainTabSpacingSpinBox->setMinimum(MIN_SPACING);
    mainTabSpacingSpinBox->setSingleStep(0.1);
    mainTabSpacingSpinBox->setValue(0.5);
    mainTabSpacingSpinBox->setFixedWidth(70);
    connect(mainTabSpacingSpinBox,SIGNAL(valueChanged(double)), this, SLOT(printSpacingInfo()));
    
    mainTabLayout->addWidget(mainTabSpacingSpinBox);
    
    mainTab->setLayout(mainTabLayout);
    
    tabMenu = new QTabWidget;
    tabMenu->addTab(mainTab,trUtf8("Main"));
    
    edenTabLayout = new QVBoxLayout;
    edenTabLayout->setAlignment(Qt::AlignTop | Qt::AlignLeft);
    
    edenPlus = new QCheckBox;
    edenPlus->setText("Grow");
    connect(edenPlus,SIGNAL(clicked(bool)), this, SLOT(checkEdenOption()));
    
    edenTabLayout->addWidget(edenPlus);
    
    edenMinus = new QCheckBox;
    edenMinus->setText("Shrink");
    connect(edenMinus,SIGNAL(clicked(bool)), this, SLOT(checkEdenOption()));
    
    edenTabLayout->addWidget(edenMinus);
    
    edenPercentLabel = new QLabel;
    edenPercentLabel->setFrameStyle(QFrame::Box | QFrame::Sunken);
    edenPercentLabel->setText(trUtf8("<b>Percent of noise:</b>"));
    
    edenTabLayout->addWidget(edenPercentLabel);
    
    edenPercent = new QSpinBox;
    edenPercent->setMaximum(100);
    edenPercent->setMinimum(0);
    edenPercent->setSingleStep(1);
    edenPercent->setSuffix(trUtf8("%"));
    connect(edenPercent,SIGNAL(valueChanged(int)), this, SLOT(checkEdenOption()));
    
    edenTabLayout->addWidget(edenPercent);
    
    edenPointConnection = new QLabel;
    edenPointConnection->setFrameStyle(QFrame::Box | QFrame::Sunken);
    edenPointConnection->setText(trUtf8("<b>Point neighborhood connections:</b>"));
    
    edenTabLayout->addWidget(edenPointConnection);
    
    edenNeighborhoodConnections0 = new QRadioButton;
    edenNeighborhoodConnections0->setText(trUtf8("No topology preservation"));
    edenNeighborhoodConnections6 = new QRadioButton;
    edenNeighborhoodConnections6->setText(trUtf8("6 - connections"));
    edenNeighborhoodConnections26 = new QRadioButton;
    edenNeighborhoodConnections26->setText(trUtf8("26 - connections"));
    edenNeighborhoodConnections26->setChecked(true);
    
    edenTabLayout->addWidget(edenNeighborhoodConnections26);
    edenTabLayout->addWidget(edenNeighborhoodConnections6);
    edenTabLayout->addWidget(edenNeighborhoodConnections0);
    
    addEdenButton = new QPushButton;
    addEdenButton->setText(trUtf8("&Add EDEN"));
    addEdenButton->setDisabled(true);
    connect(addEdenButton,SIGNAL(clicked(bool)), this, SLOT(addEden()));
    
    edenTabLayout->addWidget(addEdenButton);
    
    edenTab = new QWidget;
    edenTab->setLayout(edenTabLayout);
    
    restartNoiseButton = new QPushButton;
    restartNoiseButton->setText(trUtf8("Remove whole noise"));
    restartNoiseButton->setDisabled(true);
    connect(restartNoiseButton,SIGNAL(clicked(bool)), this, SLOT(removeNoisePink()));
    
    
    asftTabLayout = new QVBoxLayout;
    asftTabLayout->setAlignment(Qt::AlignTop | Qt::AlignLeft);
    
   
    asftRadiusLabel = new QLabel;
    asftRadiusLabel->setFrameStyle(QFrame::Box | QFrame::Sunken);
    asftRadiusLabel->setText(trUtf8("<b>Set ball radius:</b>"));
    
    asftTabLayout->addWidget(asftRadiusLabel);
    
    asftRadius = new QSpinBox;
    asftRadius->setMaximum(100);
    asftRadius->setMinimum(1);
    asftRadius->setSingleStep(1);
    asftRadius->setValue(2);
    
    asftTabLayout->addWidget(asftRadius);
    
    addAsftButton = new QPushButton;
    addAsftButton->setText(trUtf8("&Smooth tree"));
    connect(addAsftButton,SIGNAL(clicked(bool)), this, SLOT(addAsft()));
    
    asftTabLayout->addWidget(addAsftButton);
    
    asftTab = new QWidget;
    asftTab->setLayout(asftTabLayout);
    
    bigNoiseTabLayout = new QVBoxLayout;
    bigNoiseTabLayout->setAlignment(Qt::AlignTop | Qt::AlignLeft);

    bigNoiseRadiusLabel = new QLabel;
    bigNoiseRadiusLabel->setFrameStyle(QFrame::Box | QFrame::Sunken);
    bigNoiseRadiusLabel->setText(trUtf8("<b>Set ball radius:</b>"));
    bigNoiseTabLayout->addWidget(bigNoiseRadiusLabel);    
    
    bigNoiseRadius = new QSpinBox;
    bigNoiseRadius->setMaximum(10);
    bigNoiseRadius->setMinimum(1);
    bigNoiseRadius->setSingleStep(1);
    bigNoiseRadius->setValue(5);
    
    bigNoiseTabLayout->addWidget(bigNoiseRadius);
    
    addBigNoiseButton = new QPushButton;
    addBigNoiseButton->setText(trUtf8("A&dd big noise"));
    connect(addBigNoiseButton,SIGNAL(clicked(bool)), this, SLOT(addEdenForBigNoise()));
    
    bigNoiseTabLayout->addWidget(addBigNoiseButton);    
    
    bigNoiseTab = new QWidget;
    bigNoiseTab->setLayout(bigNoiseTabLayout);
    
    noiseBox = new QToolBox;
    noiseBox->addItem(edenTab,trUtf8("Small noise"));
    noiseBox->addItem(bigNoiseTab,trUtf8("Big noise"));
    noiseBox->addItem(asftTab,trUtf8("Smooth"));
    
    noiseTabLayout = new QVBoxLayout;
    noiseTabLayout->addWidget(noiseBox);
    noiseTabLayout->addWidget(restartNoiseButton);
    
    noiseTab = new QWidget;
    noiseTab->setLayout(noiseTabLayout);
    noiseTab->setDisabled(true);
    
    tabMenu->addTab(noiseTab,trUtf8("Noise"));
    

    prepareTabLayout = new QVBoxLayout;
  
    backgroundValueLabel = new QLabel;
    backgroundValueLabel->setFrameStyle(QFrame::Box | QFrame::Sunken);
    backgroundValueLabel->setText(trUtf8("<b>Set background value:</b>"));
    
    prepareTabLayout->addWidget(backgroundValueLabel);    
    
    backgroundValue = new QSpinBox;
    backgroundValue->setMaximum(1024);
    backgroundValue->setMinimum(-1024);
    backgroundValue->setSingleStep(1);
    backgroundValue->setValue(-100);
  
    prepareTabLayout->addWidget(backgroundValue); 
    
    intervalLLabel = new QLabel;
    intervalLLabel->setFrameStyle(QFrame::Box | QFrame::Sunken);
    intervalLLabel->setText(trUtf8("<b>Set left interval value:</b>"));
    
    prepareTabLayout->addWidget(intervalLLabel);
    prepareTabLayout->setAlignment(Qt::AlignTop | Qt::AlignLeft);

    intervalLValue = new QSpinBox;
    intervalLValue->setMaximum(1024);
    intervalLValue->setMinimum(-1024);
    intervalLValue->setSingleStep(1);
    intervalLValue->setValue(100);
    
    prepareTabLayout->addWidget(intervalLValue);
    
    intervalRLabel = new QLabel;
    intervalRLabel->setFrameStyle(QFrame::Box | QFrame::Sunken);
    intervalRLabel->setText(trUtf8("<b>Set right interval value:</b>"));
    
    prepareTabLayout->addWidget(intervalRLabel);
    
    intervalRValue = new QSpinBox;  
    intervalRValue->setMaximum(1024);
    intervalRValue->setMinimum(-1024);
    intervalRValue->setSingleStep(1);
    intervalRValue->setValue(800);
    
    prepareTabLayout->addWidget(intervalRValue);
    
    preparePGMButton = new QPushButton;
    preparePGMButton->setText(trUtf8("&Prepare file"));
    connect(preparePGMButton,SIGNAL(clicked(bool)), this, SLOT(preparePGMFile()));
    
    prepareTabLayout->addWidget(preparePGMButton);
  
    prepareTab = new QWidget;
    prepareTab->setLayout(prepareTabLayout);
    
    tabMenu->addTab(prepareTab,trUtf8("Prepare file"));
    
    
    layout->addWidget(tabMenu);
    
    infoBox = new QLabel;
    infoBox->setFrameStyle(QFrame::StyledPanel | QFrame::Raised);
    infoBox->setText(trUtf8("<b>Tips & Information:</b> <br/> In this frame you can find tips,etc."));
    infoBox->setMinimumHeight(150);
    infoBox->setAlignment(Qt::AlignTop | Qt::AlignLeft);
    
    layout->addWidget(infoBox);
    
    generateButton = new QPushButton;
    generateButton->setText(trUtf8("&Generate"));
    connect(generateButton,SIGNAL(clicked(bool)), this, SLOT(generateTree()));
    
    layout->addWidget(generateButton);
    
    leftPanel->setMaximumWidth(250);
    leftPanel->setLayout(layout);
    
    splitter->addWidget(leftPanel);

    setCentralWidget(splitter);

}

ThreeDTreeGUI::~ThreeDTreeGUI()
{  
  delete mainTablabel1;
  delete mainTablabel0;
  delete mainTabDiameterSpinBox;
  delete mainTabSpacingSpinBox;
  delete mainTabLayout;
  delete mainTab;
  
  delete edenPlus;
  delete edenMinus;
  delete edenPercentLabel;
  delete edenPercent;
  delete edenPointConnection;
  delete addEdenButton;
  delete edenNeighborhoodConnections0;
  delete edenNeighborhoodConnections6;
  delete edenNeighborhoodConnections26;
  delete edenTabLayout;
  delete edenTab;
 
  delete asftRadiusLabel;
  delete asftRadius;
  delete addAsftButton;
  delete asftTabLayout;
  delete asftTab;
  
  delete bigNoiseRadiusLabel;
  delete bigNoiseRadius;
  delete addBigNoiseButton;
  delete bigNoiseTabLayout;
  delete bigNoiseTab;

  delete restartNoiseButton;
  delete noiseBox;
  delete noiseTabLayout;
  delete noiseTab;
  
  delete backgroundValueLabel;
  delete backgroundValue;
  delete intervalLLabel;
  delete intervalRLabel;
  delete intervalLValue;
  delete intervalRValue;  
  delete preparePGMButton;
  delete prepareTabLayout;
  delete prepareTab;
  
  delete closeAction;
  delete saveAction;
  delete vtkWidget;
  ren->Delete();
  delete label0;
  delete generateButton;
  delete tabMenu;
  delete infoBox;
  delete layout;
  delete leftPanel;
  delete splitter;

  if(rawTree != NULL)
    rawTree->Delete();
  
  if(treeContour != NULL)
    treeContour->Delete();
  
  if(treeMapper != NULL)
    treeMapper->Delete();
  
  if(treeActor != NULL)
    treeActor->Delete();
  
  if(metaWriter != NULL)
    metaWriter->Delete();
  
  if(metaReader != NULL)
    metaReader->Delete();
}
void ThreeDTreeGUI::save()
{
  QString fileName = QFileDialog::getSaveFileName(this, trUtf8("Save File"), "",
      trUtf8("VTK Meta Image (*.mhd);;"));
 
  if (fileName != "") 
  {
    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly)) 
      std::cerr << "Can't save" << endl; //Dodać okienko z błędem
    else 
    {
     vtkImageCast *imgCast = vtkImageCast::New();
     imgCast->SetOutputScalarTypeToUnsignedChar();
     imgCast->SetInput(rawTree);
     imgCast->Update();
 
     metaWriter->SetFileName(fileName.toStdString().c_str());
     metaWriter->SetCompression(0);
     metaWriter->SetInputConnection(imgCast->GetOutputPort());
     metaWriter->Write();
     metaWriter->Update();
  
     file.close();
     }
   }
}
void ThreeDTreeGUI::printDiameterInfo()
{
  infoBox->clear();
  infoBox->setText(trUtf8("<b>Tips & Information:</b> <br/> By changing this option you can <br/> change tree high."));

}

void ThreeDTreeGUI::printSpacingInfo()
{
  infoBox->clear();
  infoBox->setText(trUtf8("<b>Tips & Information:</b> <br/> By changing this option you can <br/> change tree resolution."));
}
void ThreeDTreeGUI::generateTree()
{
  mainTab->setDisabled(true);
  noiseTab->setDisabled(true);
  saveAction->setDisabled(true);
  generateButton->setDisabled(true);
  
  treeThread =  new ComputeThread;
  connect(treeThread,SIGNAL(endCompute(vtkImageData *, QThread *)), this, SLOT(raw2PgmPink(vtkImageData *, QThread *)));
  treeThread->upDateDeep(mainTabDiameterSpinBox->value());
  treeThread->upDateSpacing(mainTabSpacingSpinBox->value());
  treeThread->start();
}

void ThreeDTreeGUI::refresh(QThread *p)
{
  
  delete p;
  
  if(treeActor)
  {
    ren->RemoveAllViewProps();
    treeActor->Delete();
    treeActor = NULL;
  }
  if(treeMapper)
  {
    treeMapper->Delete();
    treeMapper = NULL;
  }
  if(treeContour)
  {
    treeContour->Delete();
    treeContour = NULL;
  }
  if(metaReader)
  {
    metaReader->Delete();
    metaReader = NULL;
  }
  
  metaReader = vtkMetaImageReader::New();
  metaReader->SetFileName(PREPARE_MHD);
  metaReader->SetDataSpacing(rawTree->GetSpacing());
  metaReader->SetFileDimensionality(3);
  
  /*Wartosc minimalna X wczytyjemy od 4 w celu ominiecia problemu z artefaktami.
   * Gdy wartosc ta wynosila zero ladowane byly dane, ktorych faktycznie w pliku nie bylo.
   * Byc moze jest to wina PINK'a.
   */
  metaReader->SetDataExtent(/*4,*/rawTree->GetExtent()/*[1],0,rawTree->GetExtent()[3],0,rawTree->GetExtent()[5]*/);
  metaReader->SetDataOrigin(rawTree->GetOrigin());
  
  treeContour = vtkContourFilter::New();
  treeContour->SetInput(metaReader->GetOutput());
  treeContour->ComputeGradientsOff();
  treeContour->ComputeNormalsOff();
  treeContour->ComputeScalarsOff();
  treeContour->ReleaseDataFlagOn();
  treeContour->GenerateValues(1, 1.0, 1.0);
  treeContour->Update();
  
  
  vtkTriangleFilter *tringle = vtkTriangleFilter::New();
  tringle->SetInputConnection(treeContour->GetOutputPort());
  tringle->Update();
  
  vtkSTLWriter *stlWrt = vtkSTLWriter::New();
  stlWrt->SetFileTypeToBinary();
  stlWrt->SetFileName("/home/kacper/rawStlTest.stl");
  stlWrt->SetInputConnection(tringle->GetOutputPort());
  stlWrt->Write();
  stlWrt->Update();
  
  
  treeMapper = vtkPolyDataMapper::New();
  treeMapper->ReleaseDataFlagOn();
  treeMapper->ImmediateModeRenderingOn();
  treeMapper->SetInputConnection(treeContour->GetOutputPort());
  
  treeActor = vtkLODActor::New();
  treeActor->GetProperty()->SetColor(0.3,0.6,0.4);
  treeActor->SetMapper(treeMapper);
  
  ren->AddActor(treeActor);
  ren->ResetCamera();
  vtkWidget->repaint();
  generateButton->setDisabled(false); 
  saveAction->setDisabled(false);
  mainTab->setDisabled(false);
  
  noiseTab->setDisabled(false);
  
  if(isNoise)
    restartNoiseButton->setEnabled(true);
}

void ThreeDTreeGUI::checkEdenOption()
{
  if((!edenMinus->isChecked() && !edenPlus->isChecked()) || !edenPercent->value())
    addEdenButton->setDisabled(true);
  else if(!addEdenButton->isEnabled())
    addEdenButton->setEnabled(true);
}

void ThreeDTreeGUI::addEden()
{
  noiseTab->setDisabled(true);
  isNoise = true;
  
  static boost::tuple<std::string,long long unsigned int,int, int, int, std::string, vtkImageData *> tmp;
  
  boost::get<0>(tmp) = OUT_PGM;
  
  boost::get<1>(tmp) = edenPercent->value();
  boost::get<2>(tmp) = edenPlus->isChecked()?1:0;
  boost::get<3>(tmp) = edenMinus->isChecked()?1:0;
  
  if(edenNeighborhoodConnections0->isChecked())
    boost::get<4>(tmp) = 0;
  else if(edenNeighborhoodConnections6->isChecked())
    boost::get<4>(tmp) = 6;
  else if(edenNeighborhoodConnections26->isChecked())
    boost::get<4>(tmp) = 26;
  
  boost::get<5>(tmp) = OUT_PGM;
  boost::get<6>(tmp) = rawTree;
  edenThread = new pinkEden(tmp);
  connect(edenThread,SIGNAL(endCompute(QThread *)), this, SLOT(pgm2RawPink(QThread*)));
  edenThread->start();
}
void ThreeDTreeGUI::seuilPink(QThread *p)
{
  delete p;
  
  static boost::tuple<std::string,double,std::string> tmp;
  
  boost::get<0>(tmp) = OUT_PGM;
  boost::get<1>(tmp) = 1;
  boost::get<2>(tmp) = OUT_PGM;
  
  seuilThread = new pinkSeuil(tmp);
  connect(seuilThread,SIGNAL(endCompute(QThread *)), this, SLOT(framePink(QThread*)));
  seuilThread->start();  
}

void ThreeDTreeGUI::raw2PgmPink(vtkImageData *p_rawTree, QThread *p)
{
  delete p;
  
  if(rawTree)
  {
    rawTree->Delete();
    rawTree = NULL;
  }
  p_rawTree->Update();
  rawTree = vtkImageData::New();
  rawTree->DeepCopy(p_rawTree);
  
  if(rawTree)
  {
    rawTree->GetDimensions(dims);
    if(metaWriter)
    {
      metaWriter->Delete();
      metaWriter = NULL;
    }
    
    //zapisanie mapy wartosci średnicy gałęzi drzewa
    metaWriter = vtkMetaImageWriter::New();
    metaWriter->SetFileName(TMP_MHD);
    metaWriter->SetCompression(0);
    metaWriter->SetInput(rawTree);
    metaWriter->Write();
    metaWriter->Update();
    
    //Zapisanie kopii dla operacji - plik wyjsciowy z zakłuceniami
    metaWriter->RemoveAllInputs();
    metaWriter->SetFileName(PREPARE_MHD);
    metaWriter->SetCompression(0);
    metaWriter->SetInput(rawTree);
    metaWriter->Write();
    metaWriter->Update();

    static boost::tuple<std::string,int,int,int,int,int,int,std::string> tmp;
    
    boost::get<0>(tmp) = TMP_RAW;
    boost::get<1>(tmp) = dims[0];
    boost::get<2>(tmp) = dims[1];
    boost::get<3>(tmp) = dims[2];
    boost::get<4>(tmp) = 0;
    boost::get<5>(tmp) = 1;
    boost::get<6>(tmp) = 0;
    boost::get<7>(tmp) = OUT_PGM;

    raw2PgmThread = new pinkRawToPgm(tmp);
    connect(raw2PgmThread,SIGNAL(endCompute(QThread *)), this, SLOT(seuilPink(QThread *)));
    raw2PgmThread->start(); 
  }  
}
void ThreeDTreeGUI::framePink(QThread * p)
{
  delete p;
  static boost::tuple<std::string,std::string> tmp;
  boost::get<0>(tmp) = OUT_PGM;
  boost::get<1>(tmp) = FRM_PGM;
  
  frameThread = new pinkFrame(tmp);
  
  connect(frameThread,SIGNAL(endCompute(QThread *)), this, SLOT(subPink(QThread *)));
  frameThread->start();
}
void ThreeDTreeGUI::subPink(QThread *p)
{
  delete p;
  static boost::tuple<std::string,std::string,std::string> tmp;
  boost::get<0>(tmp) = OUT_PGM;
  boost::get<1>(tmp) = FRM_PGM;
  boost::get<2>(tmp) = OUT_PGM;
  
  subThread = new pinkSub(tmp);
  connect(subThread,SIGNAL(endCompute(QThread *)), this, SLOT(pgm2RawPink(QThread*)));
  subThread->start();
}

void ThreeDTreeGUI::removeNoisePink()
{
  restartNoiseButton->setDisabled(true);
  
  isNoise = false;
  
  removeTmp rm;
  rm.removeFrame();
  rm.removePGM();

  static boost::tuple<std::string,int,int,int,int,int,int,std::string> tmp;
    
  boost::get<0>(tmp) = TMP_RAW;
  boost::get<1>(tmp) = dims[0];
  boost::get<2>(tmp) = dims[1];
  boost::get<3>(tmp) = dims[2];
  boost::get<4>(tmp) = 0;
  boost::get<5>(tmp) = 1;
  boost::get<6>(tmp) = 0;
  boost::get<7>(tmp) = OUT_PGM;

  rawTree->GetDimensions(dims);
  raw2PgmThread = new pinkRawToPgm(tmp);
  connect(raw2PgmThread,SIGNAL(endCompute(QThread *)), this, SLOT(seuilPink(QThread *)));
  raw2PgmThread->start();
}

void ThreeDTreeGUI::addAsft()
{
  noiseTab->setDisabled(true);
  isNoise = true;
    
  static boost::tuple<std::string, int, int, std::string> tmp;
  boost::get<0>(tmp) = OUT_PGM;
  boost::get<1>(tmp) = asftRadius->value();
  boost::get<2>(tmp) = 26;
  boost::get<3>(tmp) = OUT_PGM;
  
  asftThread = new pinkAsft(tmp);
  
  connect(asftThread,SIGNAL(endCompute(QThread *)), this, SLOT(pgm2RawPink(QThread*)));
  asftThread->start();
}

void ThreeDTreeGUI::addEdenForBigNoise()
{
  noiseTab->setDisabled(true);
  isNoise = true;
  
  static boost::tuple<std::string,long long unsigned int,int, int, int, std::string, vtkImageData *> tmp;
  
  boost::get<0>(tmp) = OUT_PGM;
  
  boost::get<1>(tmp) = 200;
  boost::get<2>(tmp) = 1;
  boost::get<3>(tmp) = 1;

  boost::get<4>(tmp) = 26;
  
  boost::get<5>(tmp) = OUT_PGM;
  boost::get<6>(tmp) = rawTree;
  
  edenThread = new pinkEden(tmp);
  connect(edenThread,SIGNAL(endCompute(QThread *)), this, SLOT(addAsftForBigNoise(QThread *)));
  edenThread->start();
}

void ThreeDTreeGUI::addAsftForBigNoise(QThread *p)
{
  delete p;
  
  noiseTab->setDisabled(true);
  isNoise = true;
    
  static boost::tuple<std::string, int, int, std::string> tmp;
  boost::get<0>(tmp) = OUT_PGM;
  boost::get<1>(tmp) = bigNoiseRadius->value();
  boost::get<2>(tmp) = 26;
  boost::get<3>(tmp) = OUT_PGM;
  
  asftThread = new pinkAsft(tmp);
  
  connect(asftThread,SIGNAL(endCompute(QThread *)), this, SLOT(pgm2RawPink(QThread*)));
  asftThread->start();
}
void ThreeDTreeGUI::terminateThread(QThread* p)
{
  delete p;
}

void ThreeDTreeGUI::preparePGMFile()
{
  static boost::tuple<vtkImageData *, int, int, int, std::string> tmp;
  
  vtkImageData *rawData = metaReader->GetOutput();
  
  boost::get<0>(tmp) = rawData;
  boost::get<1>(tmp) = backgroundValue->value();
  boost::get<2>(tmp) = intervalLValue->value();
  boost::get<3>(tmp) = intervalRValue->value();
  boost::get<4>(tmp) = PREPARE_MHD;
  
  prepareThread = new PrepareFile(tmp);
  
  connect(prepareThread,SIGNAL(endCompute(QThread*)), this, SLOT(terminateThread(QThread*)));
  prepareThread->start();
}
void ThreeDTreeGUI::pgm2RawPink(QThread* p)
{
  delete p;

  static boost::tuple<std::string,std::string> tmp;
    
  boost::get<0>(tmp) = OUT_PGM;
  boost::get<1>(tmp) = PREPARE_RAW;

  pgm2RawThread = new pinkPgmToRaw(tmp);
  connect(pgm2RawThread,SIGNAL(endCompute(QThread *)), this, SLOT(refresh(QThread*)));
  pgm2RawThread->start();
}

#include "3DTreeGUI.moc"
