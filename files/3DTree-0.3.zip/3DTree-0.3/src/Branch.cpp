/*=========================================================================
  
  Program:   3D Human Airway Tree
  Module:    Branch.cpp
  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.
  
     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.
     
=========================================================================*/

//For more info please take a look at Branch.h

#include "Branch.h"
#include "AlgorithmConstData.h"
#include <vtkProperty.h>
#include <vtkTubeFilter.h>
#include <vtkCellArray.h>
#include <vtkMath.h>
#include <vtkCleanPolyData.h>
#include "boost/tuple/tuple.hpp"
#include <EquationRandomizer.h>
#include <vtkSmoothPolyDataFilter.h>

Branch::Branch(double r, double p_h, twisting p_twist) : BasicObject(), h(p_h)
{
    isEndBranch = false;
    branchRegion = vtkPolyData::New();
    EquationRandomizer *equationRandomizer = new EquationRandomizer();
    equationRandomizer->SearchAnotherEquation();
    boost::tuple<double, double> result;
    //    rS = /*random() % *//*(int)*/r; //Wylosowanie wartości promienia
    
    //Wygenerowanie punktów
    points = vtkPoints::New();
    
    //Stworz skręcenia tylko do gałęzi o średnicy większej równej 5
    if(p_twist == TWIST_ON)
    {
        nV = h+15/*static_cast<int>(h/(r/(r/2))) - 20*/;
        rS =  r/ 4.0;
        nCyc = 1.0;
//        equation = rand() % 9 + 1;
        
        for(int i = 0; i < nV; i++)
        {
            result = equationRandomizer->GetValue(rS,nCyc,nV,i); 
            if(i >= 15)
            {
                
                vX = boost::get<0>(result);
                vZ = boost::get<1>(result);
            }
            else if( i <= 6)
            {
                vX = 0.0;
                vZ = 0.0; 
            }
            else 
            {
 
                vX = sin(boost::get<0>(result))/1.2f;
                vZ = sin(boost::get<1>(result))/1.2f;
            }
            vY = h * i / nV;
            points->InsertPoint(i, vX, vY, vZ);
        }
    }
    else
    {  nV = static_cast<int>(SHAPE_RES*r);
        rS = 0.0;
        nCyc = 1.0;
        for(int i = 0; i < nV; i++)
        {
            // Spiral coordinates
            vX = 0;
            vZ = 0;
            vY = h * i / nV;
            points->InsertPoint(i, vX, vY, vZ);
        }
    }
    
    lines = vtkCellArray::New();
    lines->InsertNextCell(nV);
    
    for (int i = 0; i < nV; i++)
    {
        lines->InsertCellPoint(i);
    }
    
    polyData = vtkPolyData::New();
    polyData->SetPoints(points);
    polyData->SetLines(lines);
    
    vtkCleanPolyData *cleaner = vtkCleanPolyData::New();
    cleaner->SetInput(polyData);
    
    
    
    //Stworzenie rury do okoła linii
    tubeFilter = vtkTubeFilter::New();
    tubeFilter->SetInput(cleaner->GetOutput());
    tubeFilter->SetRadius(r);
    //! Ustawia rozdzielczość gałęzi. Zobacz @ref AlgorithmConstData.h
    tubeFilter->SetNumberOfSides(SHAPE_RES*r);
    tubeFilter->CappingOn();
    
    
    triFilter = vtkTriangleFilter::New();
    triFilter->SetInput(tubeFilter->GetOutput());
    triFilter->Update();
    
//    cleaner->Delete();
    
    delete equationRandomizer;
    
    BasicObject::SetPipeline(triFilter);
}
Branch::Branch(const double r, const double p_h, vtkTransform *relativeTrans, int rootEQ, twisting p_twist) : BasicObject(), h(p_h)
{
    isEndBranch = false;
    branchRegion = vtkPolyData::New();
    
    //    rS = /*random() % *//*(int)*/r; //Wylosowanie wartości promienia
    
    points = vtkPoints::New();
    EquationRandomizer *equationRandomizer = new EquationRandomizer();
    equationRandomizer->SearchAnotherEquation();
    boost::tuple<double, double> result;
    //Stworz skręcenia tylko do gałęzi o średnicy większej równej 5
    if(r * 2.0 >= 5 && p_twist == TWIST_ON)
    {
        nV = static_cast<int>(round(h/4.0)+15); /*(h/(r/(r/2))) - 1*/;
        rS  = r/ 4.0;
        nCyc = 1.0;
        
        equation = rand() % 9 + 1;
        cout << equation << " " << rootEQ << endl;
        //      while(equation == rootEQ)
        //      {
        //        equation = (random() % 8) +1;
        //      }
        
        for(int i = 0; i < nV; i++)
        {
            result = equationRandomizer->GetValue(rS,nCyc,nV,i); 
            if(i > 2 && i < nV - 2)
            {

                vX = boost::get<0>(result);
                vZ = boost::get<1>(result);
            }
//            else
//            {
////                vX = 0;
////                vZ = 0;
//                vX = sin(boost::get<0>(result))/*/1.2f*/;
//                vZ = sin(boost::get<1>(result))/*/1.2f*/;                
//            }
            else if( i <= 1 || i > nV - 1)
            {
                vX = 0.0;
                vZ = 0.0; 
            }
            else 
            {
 
                vX = sin(boost::get<0>(result))/1.2f;
                vZ = sin(boost::get<1>(result))/1.2f;
            }
            vY = h * i / nV;
            points->InsertPoint(i, vX, vY, vZ);
        }
    }
    else
    {
        nV = static_cast<int>(SHAPE_RES*r);
        rS = 0.0;
        nCyc = 1.0;
        for(int i = 0; i < nV; i++)
        {
            // Spiral coordinates
            vX = 0;
            vZ = 0;
            vY = h * i / nV;
            points->InsertPoint(i, vX, vY, vZ);
        }
    }
    
    lines = vtkCellArray::New();
    lines->InsertNextCell(nV);
    
    for (int i = 0; i < nV; i++)
    {
        lines->InsertCellPoint(i);
    }
    
    polyData = vtkPolyData::New();
    polyData->SetPoints(points);
    polyData->SetLines(lines);
    
//    vtkCleanPolyData *cleaner = vtkCleanPolyData::New();
//    cleaner->SetInput(polyData);
    
    tubeFilter = vtkTubeFilter::New();
    tubeFilter->SetInput(polyData);
    tubeFilter->SetRadius(r);
    //! Ustawia rozdzielczość gałęzi. Zobacz @ref AlgorithmConstData.h
    tubeFilter->SetNumberOfSides(SHAPE_RES);
    tubeFilter->CappingOn();
    
    triFilter = vtkTriangleFilter::New();
    triFilter->SetInput(tubeFilter->GetOutput());
    triFilter->Update();
    BasicObject::SetPipeline(relativeTrans, triFilter);
    
    delete equationRandomizer;
//    cleaner->Delete();
}
Branch::~Branch()
{
    triFilter->Delete();
    tubeFilter->Delete();
    polyData->Delete();
    points->Delete();
    lines->Delete();
    
    if(branchRegion != NULL)
    {
        branchRegion->Delete();
    }
}
boost::shared_ptr<Branch> Branch::New(double r, double h, twisting p_twist)
{
    boost::shared_ptr<Branch> node(new Branch(r,h, p_twist));
    return node;
}
boost::shared_ptr<Branch> Branch::New(double r, double h, vtkTransform *relativeTrans, int rootEQ, twisting p_twist)
{
    boost::shared_ptr<Branch> node(new Branch(r,h, relativeTrans, rootEQ, p_twist));
    return node;
}
void Branch::RemoveRegion()
{
    if(branchRegion != NULL)
    {
        branchRegion->Delete();
    }
    
    branchRegion = NULL;
    
}
