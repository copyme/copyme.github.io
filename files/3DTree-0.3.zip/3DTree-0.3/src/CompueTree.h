/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    CompueTree.h

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef COMPUETREE_H
#define COMPUETREE_H

#include <QtCore/QThread>

#include "SimpleOrganShape.h"
#include <boost/shared_ptr.hpp>
#include <list>
#include "SimpleOrganShape.h"
#include "Branch.h"
#include "TreeBranchProducer.h"
#include "TreeBranchVoxelizer.h"


class ComputeThread : public QThread
{
Q_OBJECT
 
public:
  ComputeThread();
  virtual ~ComputeThread();
  void upDateSpacing(float p_spacing){spacing = p_spacing;}
  void upDateDeep(int p_deep){deep = p_deep;}
protected:
  virtual void run();
private:
  SimpleOrganShape *Shape;
  boost::shared_ptr<Branch> root;
  std::list<boost::shared_ptr<Branch> > BranchList;
  TreeBranchProducer *produceBranch;
  TreeBranchVoxelizer *Voxelizer;
  float spacing;
  int deep;
signals:
  vtkImageData *endCompute(vtkImageData *, QThread *);
};

#endif // COMPUETREE_H
