/*!
    @mainpage
    @par Opis:
    Program generuje model objętościowy ludzkiego
    drzewa oskrzelowago z uwzględnieniem grubości ścian gałęzi.
    W programie wykorzystano algorytm generujący drzewo oskrzelowe 
    zaprojektowany przez Hiroko Kitaoka, Ryuji Takaki oraz Bela Suki.
    @par Wykorzystane oprogramowanie innych autorów:
    @par biblioteki:
    Program został napisany z wykorzystaniem bibliotek systemu graficznego
    VTK @a http://vtk.org ,bibliotek Boost @a http://boost.org , 
    @n
    @par klas:
    - vtkBooleanOperationPolyDataFilter
    - vtkImplicitPolyData
    - vtkIntersectionPolyDataFilter
    - vtkDistancePolyDataFilter
    @n
    autorstwa Quammen C., Weigle C., Taylor II R.M.- The University of North Carolina at Chapel Hill
    @a http://www.insight-journal.org/browse/publication/797
    @n @n
    - vtkCollisionDetectionFilter @n
    autorstwa Goodwina Lawlora - Bioengineering Research Centre
    in the Mechanical Engineering Department in University College Dublin, Ireland
    mail: @a goodwin.lawlor@ucd.ie strona:
    @a http://www.bioengineering-research.com/
    @version 0.1b1
    @date Copyright (C) 2011 
    @author Kacper Pluta
    @par Kontakt:
    e-mail: @a kacperp@wsinf.edu.pl strona domowa: @a http://leo.wsinf.edu.pl/~kacperp/3dtree
    @par Licencja:
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.@n @n
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.@n @n
    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
    
    @page TODO
    @date Stan na 08.11.2011r.
    - Ogólne
      -# Dopracowanie kodu - usunięcie problemu z testem zderzenia gałęzi z regionem drzewa
      powoduje wysypanie się programu przy wartości MAX_RECURR większej od 10
    - Implementacja algorytmu
      -# Dodać dodatkowe reguły
    - Wokselizacja
      -# Napisać kod generujący ścianę oskrzela, o odpowiedniej grubości
    - Dodać zanieczyszczenia
    -# Skręcenia
    -# Wgryzy
    -# Pęcherze - bąble
    -# Szum w obrazie RAW - metoda EDEN z PINK
    -# artefakty ruchowe - "wyciągniecie monety ze stosu"
    - Interface
      -# Pomyśleć nad GUI w QT
*/

#include <QtGui/QApplication>
#include <3DTreeGUI.h>
#include <removeTmp.h>

int main(int argc, char **argv) 
{
  //Kasowanie starych plików pomocnyczych
  removeTmp rm;
  rm.removeAll();
  
  QApplication app(argc, argv);
  ThreeDTreeGUI MainWin;
  MainWin.show();
  
  return app.exec();
}
