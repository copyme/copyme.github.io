/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    AlgorithmConstData.h

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#ifndef ALGORITHCONSTDATA_H
#define ALGORITHCONSTDATA_H

/** Graniczna wartość średnicy gałęzi - obraz zbudowany z wokseli opiera się o typ U_CHAR
 * dlatego nie generujemy gałęzi o średnicy niższej niż 1
 */
#define QC 1.0

//#define MAX_DIAMETER 26.0
#define MAX_DIAMETER 18.0



extern int SmallBranchCount;

//! Potęga równania obliczającego współczynnik przepływu
#define FLOW_P 2.8

//! Górna wartość graniczna dla współczynnika podziału rozwidlenia
#define MAX_F_RATIO 0.5

//! Dolna wartość graniczna dla współczynnika podziału rozwidlenia
#define MIN_F_RATIO 0.05
//! Poniżej tej wartości przepływ ustaje
#define ERROR_F_RATIO 0.0

//! Reguła 7, średnica * 3
#define LENGTH_RATIO 3.0

//! Steruje rozdzielczością pojedynczej gałęzi
#define SHAPE_RES 15

//! Maksymalna liczba wątków konwertujących drzewo do grafiki objętościowej
#define MAX_THREAD 1

#ifdef __unix
#define OUT_PGM "/tmp/_out.pgm"
#define FRM_PGM "/tmp/_frame.pgm"
#define TMP_MHD "/tmp/_tmp.mhd"
#define TMP_RAW "/tmp/_tmp.raw"
#define PREPARE_RAW "/tmp/_prepare.raw"
#define PREPARE_MHD "/tmp/_prepare.mhd"
#endif
#ifdef WINNT
#define OUT_PGM "%Windows%\Temp\_out.pgm"
#define FRM_PGM "%Windows%\Temp\_frame.pgm"
#define TMP_MHD "%Windows%\Temp\_tmp.mhd"
#define TMP_RAW "%Windows%\Temp\_tmp.raw"
#endif


#endif // ALGORITHCONSTDATA_H
