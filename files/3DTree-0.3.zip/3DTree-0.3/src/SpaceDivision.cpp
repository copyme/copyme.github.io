/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    SpaceDivision.cpp

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

//For more info please take a look at SpaceDivisionAlgorithm.h

#include "SpaceDivision.h"

SpaceDivision::SpaceDivision()
{
  clipper = vtkClipPolyData::New();
  //Wygenerowanie drugiej polowy przecietego obiektu
  clipper->GenerateClippedOutputOn();
  clipper->ReleaseDataFlagOn();
  
  boundaryEdges = vtkFeatureEdges::New();
  boundaryEdges->BoundaryEdgesOn();
  boundaryEdges->ReleaseDataFlagOn();
  boundaryEdges->FeatureEdgesOff();
  boundaryEdges->NonManifoldEdgesOff();
  boundaryEdges->ManifoldEdgesOff();
  
  cutStrips = vtkStripper::New();
  cutStrips->ReleaseDataFlagOn();
  
  fixNewWall = vtkDensifyPolyData::New();
  fixNewWall->ReleaseDataFlagOn();
  
  newRegion = vtkAppendPolyData::New();
  newRegion->ReleaseDataFlagOn();
  
  improveNewWall = vtkTriangleFilter::New();
  improveNewWall->ReleaseDataFlagOn();
  improveNewWall->PassLinesOn();
  improveNewWall->PassVertsOn();
}

SpaceDivision::~SpaceDivision()
{
  clipper->Delete();
  boundaryEdges->Delete();
  cutStrips->Delete();
  fixNewWall->Delete();
  improveNewWall->Delete();
}

void SpaceDivision::RemoveAllInputs()
{
  clipper->RemoveAllInputs();
  boundaryEdges->RemoveAllInputs();
  cutStrips->RemoveAllInputs();
  newRegion->RemoveAllInputs();
  fixNewWall->RemoveAllInputs();
  improveNewWall->RemoveAllInputs();
}

vtkPolyData* SpaceDivision::AddBoundary(vtkPolyData* addWallToThisPoly)
{
    //Now extract feature edges
    boundaryEdges->SetInput(addWallToThisPoly);

    //Generates triangle strips
    cutStrips->SetInputConnection(boundaryEdges->GetOutputPort());
    cutStrips->Update();
 
    //Change the polylines into polygons
    vtkPolyData  *boundaryPoly = vtkPolyData::New();
    boundaryPoly->SetPoints(cutStrips->GetOutput()->GetPoints());
    boundaryPoly->SetPolys(cutStrips->GetOutput()->GetLines());
 
    fixNewWall->SetInput(boundaryPoly);

    improveNewWall->SetInputConnection(fixNewWall->GetOutputPort());

    //Connect to a new region with a new wall.
    newRegion->AddInput(addWallToThisPoly);
    newRegion->AddInputConnection(improveNewWall->GetOutputPort());
    newRegion->Update();
    
    //Kasujemy tymczasowy obiekt
    boundaryPoly->Delete();
    
    return newRegion->GetOutput();
}


void SpaceDivision::ClipBoundaries(vtkPlane *plane, vtkPolyData* surfaces, vtkPolyData *tmp[4])
{
  RemoveAllInputs();
  
  //Przetnij obiekt zgodnie z plaszczyzną.
  clipper->SetInput(surfaces);
  clipper->SetClipFunction(plane);
  clipper->Update();

  //Tylko jeśli siatka wyjscie zawiera jakies wielokąty
  if(clipper->GetOutput()->GetNumberOfPolys() > 0 && clipper->GetClippedOutput()->GetNumberOfPolys() > 0)
  {
    for(int i = 0; i < 4;i++)
    {
      tmp[i] = vtkPolyData::New();
    }
    
    tmp[0]->DeepCopy(AddBoundary(clipper->GetOutput()));
    tmp[1]->DeepCopy(clipper->GetOutput());
    tmp[3]->DeepCopy(clipper->GetClippedOutput());
    
    RemoveAllInputs();
    //Kasujemy tymczasowy obiekt
    
    //Ostatni region ze sciana
    tmp[2]->DeepCopy(AddBoundary(tmp[3]));
    
  }
  else
  {    
    for(int i = 0; i < 4;i++)
      tmp[i] = NULL;
  }
}