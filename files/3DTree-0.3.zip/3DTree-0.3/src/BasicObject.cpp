/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    BasicObject.cpp

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

// Więcej informacji zawarto w pliku BasicObject.h

#include <cstdlib>
#include "BasicObject.h"

BasicObject::BasicObject()
{
  objTransform = vtkTransform::New();
  polyDataTransFilter = vtkTransformPolyDataFilter::New();
}

BasicObject::~BasicObject()
{
  objTransform->Delete();
  polyDataTransFilter->Delete();
}
vtkPolyData* BasicObject::GetOutput() const
{
  polyDataTransFilter->Update();
  return polyDataTransFilter->GetOutput();
}
vtkAlgorithmOutput* BasicObject::GetOutputPort() const
{
  polyDataTransFilter->Update();
  return polyDataTransFilter->GetOutputPort();

}
