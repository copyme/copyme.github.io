/*
    <one line to give the program's name and a brief idea of what it does.>
    Copyright (C) 2011  Kacper Pluta <kacperp@wsinf.edu.pl>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include "TreeBranchConsumer.h"
#include <vtkPolyDataWriter.h>
#include <vtkPolyDataReader.h>
#include <vtkBooleanOperationPolyDataFilter.h>
#include <ObjectConnector.hpp>
#include <vtkTriangleFilter.h>
#include "AlgorithmConstData.h"

void TreeBranchConsumer::Consumer()
{
  //sprawdzić czy tak będzie działać. Ogólnie ważne jest by nie zwracać przez
  //Connect() wyjścia filtru bezpośrednio ale przez wskaźnik do obiektu wyjściowego
  //innaczej się wywala - TEST tak też może. 
  vtkPolyData *tmp_all;
  while(pile.size() >=2)
  { 
    boost::shared_ptr<Branch> tmp = pile.top();
    pile.pop();
    boost::shared_ptr<Branch> tmp2 = pile.top();
    pile.pop();
    
    tmp_all = tmpPolyData;

    tmpPolyData = meta::helpers::Connect<boost::shared_ptr<Branch>, vtkPolyData>(tmp,tmp2,tmpPolyData);
    
    tmp.reset();
    tmp2.reset();
    tmp->Delete();
    tmp2->Delete();
    tmp_all->Delete();
  }
}

boost::thread *TreeBranchConsumer::Start()
{
  t = new boost::thread(&TreeBranchConsumer::Consumer,this);
  return t;
}
