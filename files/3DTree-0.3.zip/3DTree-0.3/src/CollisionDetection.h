/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    CollisionDetection.h

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

/** @brief Klasa ta przeprowadza test kolizji pomiędzy galezia i jej regionem.
 * 
 * @return W przypadku wystapenia kolizji zwracana jest wartość większa niż
 * zero.
 */


#ifndef COLLISIONDETECTOR_H
#define COLLISIONDETECTOR_H

#include <vtkPolyData.h>
#include <vtkTransform.h>
#include <vtkCollisionDetectionFilter.h>
#include "Branch.h"
#include <boost/shared_ptr.hpp>

class CollisionDetector
{
private:
  //!Transformacja dla zdrzenia
  vtkTransform *transform0;
  vtkTransform *transform1;
  //!Obiekt klasy umoziwiajacej dokonanie testu kolizji
  vtkCollisionDetectionFilter *collider;
  void RemoveAllInputs();
public:
  CollisionDetector();
  virtual ~CollisionDetector();
  int CollisionDetection(vtkPolyData *region,  boost::shared_ptr<Branch> owner);
  
};

#endif // COLLISIONDETECTOR