/*
    <one line to give the program's name and a brief idea of what it does.>
    Copyright (C) 2011  Kacper Pluta <kacperp@wsinf.edu.pl>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/


#ifndef OBJECTCONNECTOR_H
#define OBJECTCONNECTOR_H

#include <vtkPolyData.h>
#include <vtkTriangleFilter.h>
#include <vtkBooleanOperationPolyDataFilter.h>

namespace meta
{
  namespace helpers
  {
    template<typename T>
    vtkPolyData* Connect(T &e0, T &e1, T &e2)
    {  
      vtkTriangleFilter *tf0 = vtkTriangleFilter::New();
      tf0->ReleaseDataFlagOn();
      tf0->PassVertsOff();
      tf0->PassLinesOff();
      tf0->SetInputConnection(e0.GetOutputPort());
   
      vtkTriangleFilter *tf1 = vtkTriangleFilter::New();
      tf1->ReleaseDataFlagOn();
      tf1->PassVertsOff();
      tf1->PassLinesOff();
      tf1->SetInputConnection(e1.GetOutputPort());
 
      vtkTriangleFilter *tf2 = vtkTriangleFilter::New();  
      tf2->ReleaseDataFlagOn();
      tf2->PassVertsOff();
      tf2->PassLinesOff();
      tf2->SetInputConnection(e2->GetOutputPort());
       
      vtkBooleanOperationPolyDataFilter *b1 = vtkBooleanOperationPolyDataFilter::New();
      b1->ReleaseDataFlagOn();
      b1->SetOperationToUnion();
      b1->AddInputConnection(0,tf0->GetOutputPort());
      b1->AddInputConnection(1,tf1->GetOutputPort());
      
      b1->Update();
        
      vtkBooleanOperationPolyDataFilter *b2 = vtkBooleanOperationPolyDataFilter::New();
      b2->ReleaseDataFlagOn();
      b2->SetOperationToUnion();
      b2->AddInputConnection(1,b1->GetOutputPort());
      b2->AddInputConnection(0,tf2->GetOutputPort());

      b2->Update();
      
      tf0->Delete();
      tf1->Delete();
      tf2->Delete();
      b1->Delete();
      
      vtkPolyData *tmp = b2->GetOutput();
  
      return tmp;
    }

    template<class T, class P>
    vtkPolyData* Connect(T &e0, T &e1, P &e2)
    { 
      vtkTriangleFilter *tf0 = vtkTriangleFilter::New();
      tf0->ReleaseDataFlagOn();
      tf0->PassVertsOff();
      tf0->PassLinesOff();
      tf0->SetInput(e0.GetOutput());
   
      vtkTriangleFilter *tf1 = vtkTriangleFilter::New();
      tf1->ReleaseDataFlagOn();
      tf1->PassVertsOff();
      tf1->PassLinesOff();
      tf1->SetInput(e1.GetOutput());
 
      vtkTriangleFilter *tf2 = vtkTriangleFilter::New();  
      tf2->ReleaseDataFlagOn();
      tf2->PassVertsOff();
      tf2->PassLinesOff();
      tf2->SetInputConnection(e2->GetOutputPort());
       
      vtkBooleanOperationPolyDataFilter *b1 = vtkBooleanOperationPolyDataFilter::New();
      b1->ReleaseDataFlagOn();
      b1->SetOperationToUnion();
      b1->AddInputConnection(0,tf0->GetOutputPort());
      b1->AddInputConnection(1,tf1->GetOutputPort());
      
      b1->Update();
        
      vtkBooleanOperationPolyDataFilter *b2 = vtkBooleanOperationPolyDataFilter::New();
      b2->ReleaseDataFlagOn();
      b2->SetOperationToUnion();
      b2->AddInputConnection(1,b1->GetOutputPort());
      b2->AddInputConnection(0,tf2->GetOutputPort());

      b2->Update();
  
      tf0->Delete();
      tf1->Delete();
      tf2->Delete();
      b1->Delete();
  
      return b2->GetOutput();
    }
    template<class T, class P>
    vtkPolyData* Connect(T &e0, T &e1, P *e2)
    { 
      vtkTriangleFilter *tf0 = vtkTriangleFilter::New();
      tf0->ReleaseDataFlagOn();
      tf0->PassVertsOff();
      tf0->PassLinesOff();
      tf0->SetInputConnection(e0->GetOutputPort());
   
      vtkTriangleFilter *tf1 = vtkTriangleFilter::New();
      tf1->ReleaseDataFlagOn();
      tf1->PassVertsOff();
      tf1->PassLinesOff();
      tf1->SetInputConnection(e1->GetOutputPort());
 
      vtkTriangleFilter *tf2 = vtkTriangleFilter::New();  
      tf2->ReleaseDataFlagOn();
      tf2->PassVertsOff();
      tf2->PassLinesOff();
      tf2->SetInput(e2);
       
      vtkBooleanOperationPolyDataFilter *b1 = vtkBooleanOperationPolyDataFilter::New();
      b1->ReleaseDataFlagOn();
      b1->SetOperationToUnion();
      b1->AddInputConnection(0,tf0->GetOutputPort());
      b1->AddInputConnection(1,tf1->GetOutputPort());
      
      b1->Update();
        
      vtkBooleanOperationPolyDataFilter *b2 = vtkBooleanOperationPolyDataFilter::New();
      b2->ReleaseDataFlagOn();
      b2->SetOperationToUnion();
      b2->AddInputConnection(1,b1->GetOutputPort());
      b2->AddInputConnection(0,tf2->GetOutputPort());

      b2->Update();
  
      tf0->Delete();
      tf1->Delete();
      tf2->Delete();
      b1->Delete();
  
      return b2->GetOutput();
    }
  }
}
    
#endif // OBJECTCONNECTOR_H
