/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    removeTmp.h

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
//! Klasa ta po prostu pozwala na proste wykasowanie plików pomocniczych

#ifndef REMOVE_TMP
#define REMOVE_TMP

#include <boost/filesystem.hpp> 

class removeTmp
{
private:
  boost::filesystem::wpath file0;
  boost::filesystem::wpath file1;
  boost::filesystem::wpath file2;
  boost::filesystem::wpath file3;
public:
  removeTmp();
  virtual ~removeTmp(){}
  void removeAll();
  void removeRAW();
  void removeFrame();
  void removePGM();
};

#endif