/*
    <one line to give the program's name and a brief idea of what it does.>
    Copyright (C) 2011  Kacper Pluta <kacperp@wsinf.edu.pl>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/


#ifndef TREEBRANCHCONSUMER_H
#define TREEBRANCHCONSUMER_H

#include <stack>
#include <boost/thread.hpp>
#include <vtkPolyData.h>
#include "Branch.h"

class TreeBranchConsumer
{
private:
  std::stack<boost::shared_ptr<Branch> > &pile;
  boost::shared_ptr<Branch> masterRoot;
  vtkPolyData *tmpPolyData;
  boost::thread *t;
  void Consumer();
public:
  vtkPolyData *GetOutput() const {return tmpPolyData;}
  TreeBranchConsumer(std::stack<boost::shared_ptr<Branch> > &p_pile, boost::shared_ptr<Branch> p_masterRootRegion) : pile(p_pile), masterRoot(p_masterRootRegion){tmpPolyData = p_masterRootRegion->GetOutput();}
  ~TreeBranchConsumer(){}
  boost::thread *Start();
  
};
#endif // TREEBRANCHCONSUMER_H
