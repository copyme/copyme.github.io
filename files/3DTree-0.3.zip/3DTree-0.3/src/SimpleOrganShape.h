/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    SimpleOrganShape.h
  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

/** @brief Klasa ta pozwala na utworzenie prostego kształtu organu danego
 * równaniem: z = 2 *15^-3*([x^2 + (1.5*y)^2]^2), 0 <= z <= 30 */

#ifndef SIMPLEORGANSHAPE_H
#define SIMPLEORGANSHAPE_H

#include <vtkImplicitFunction.h>
#include <vtkSampleFunction.h>
#include <vtkContourFilter.h>
#include <vtkImageData.h>
#include "BasicObject.h"

class SimpleOrganShape : public vtkImplicitFunction, public BasicObject
{
private:
  vtkSampleFunction *imlFunction;
  vtkContourFilter *shapeContour;
public:
    //! Makro tworzy odpowiednie metody dla klasy dziedziczącej z klas biblioteki VTK
    vtkTypeMacro(SimpleOrganShape,vtkImplicitFunction)
    //! Definicja tej metody generowana jest przez makro vtkStandardNewMacro()
    static SimpleOrganShape *New();
    //! Dokonuje obliczeń powierzchni oraz koniecznych konwersji.
    void Evaluate();
    //! Pozwala na wykasowanie wszystkich pod obiektów jak i samego obiektu.
    virtual void Delete(){imlFunction->Delete(); shapeContour->Delete(); this->vtkImplicitFunction::Delete();}
protected:
    //! Wyliczanie funkcji gradient nie zostało zaimplementowane.
    virtual void EvaluateGradient(double x[3], double g[3]){}
    //! Metoda służy do wyliczenia równania opisującego powierzchnię.
    virtual double EvaluateFunction(double x[3]);
    SimpleOrganShape();
    virtual ~SimpleOrganShape(){}
};

#endif // SIMPLEORGANSHAPE_H
