#include <cstdlib>
#include <ctime>
#include <vtkMath.h>
#include "EquationRandomizer.h"

int EquationRandomizer::equation = 0;

EquationRandomizer::EquationRandomizer()
{
    srand(time(0));
    equation = rand() % 9 + 1;
//    equation = 3 ;
}

void EquationRandomizer::SearchAnotherEquation()
{
    int tmpEqu = equation;
    
    while(tmpEqu == equation)
        equation = rand() % 9 + 1;
}
boost::tuple<double, double> EquationRandomizer::GetValue(double rS, unsigned int nCyc, int nV, int i)
{
    boost::tuple<double, double> result; 
    if(equation <= 1)
    {
        boost::get<0>(result) = rS * -cos(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
        boost::get<1>(result) = rS * sin(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
    }
    else if (equation <= 2)
    {
        boost::get<0>(result) = rS * cos(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
        boost::get<1>(result) = rS * -sin(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
    }
    else if (equation <= 3)
    {
        boost::get<0>(result) = rS * -sin(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
        boost::get<1>(result) = rS * cos(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
    }
    else if (equation <= 4)
    {
        boost::get<0>(result) = rS * sin(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
        boost::get<1>(result) = rS * -cos(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
    }
    else if (equation <= 5)
    {
        boost::get<0>(result) = rS * sin(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
        boost::get<1>(result) = rS * cos(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
    }
    else if (equation <= 6)
    {
        boost::get<0>(result) = rS * cos(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
        boost::get<1>(result) = rS * sin(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
    }
    else if (equation <= 7)
    {
        boost::get<0>(result) = rS * -cos(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
        boost::get<1>(result) = rS * -sin(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
    }
    else if (equation <= 8)
    {
        boost::get<0>(result) = rS * -sin(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
        boost::get<1>(result) = rS * -cos(2 * vtkMath::Pi() * nCyc * i / (nV - 1));
    }
    else
    {
        boost::get<0>(result) = 0;
        boost::get<1>(result) = 0;
    }
    return result;
}
