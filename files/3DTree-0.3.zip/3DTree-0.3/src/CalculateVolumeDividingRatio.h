/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    CalculateVolumeDividingRatio.h

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

/** @brief Funkcja ta pozwala obliczyć "R" - stosunek przepływu/objętości. 
 * 
 * Współczynnik podziału objętości obliczany jest w następujący sposób.
 * Jeśli region płuca rodzica oraz jego współrzędne są znane należy obliczyć
 * objętość prostopadłościanu, w którym zawiera się region. Następnie
 * obliczamy objętość prostopadłościanu o bokach 20 razy mniejszych od
 * prostopadłościanu zawierającego cały region. Wymienione wyżej kroki powtarzamy
 * dla regionu dziecka. Następnie obliczamy stosunek mniejszych prostopadłościanów
 * dziecka do mniejszych prostopadłościanów rodzica. 
*/

#ifndef CALCULATER_H
#define CALCULATER_H

#include "AlgorithmConstData.h"
#include <vtkPolyData.h>

float CalculateVolumeDividingRatio(vtkPolyData* parentRegion, vtkPolyData* childRegion);

#endif // CALCULATER