/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    removeTmp.cpp

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "removeTmp.h"
#include <AlgorithmConstData.h>

removeTmp::removeTmp() : file0(OUT_PGM),file1(TMP_MHD), file2(TMP_RAW), file3(FRM_PGM)
{
  
}

void removeTmp::removeAll()
{
  if(boost::filesystem::exists(file0))
     boost::filesystem::remove(file0);
  
  if(boost::filesystem::exists(file1))
     boost::filesystem::remove(file1); 
  
  if(boost::filesystem::exists(file2))
     boost::filesystem::remove(file2);
  
  if(boost::filesystem::exists(file3))
     boost::filesystem::remove(file3); 
}
void removeTmp::removeFrame()
{
  if(boost::filesystem::exists(file3))
     boost::filesystem::remove(file3); 
}
void removeTmp::removeRAW()
{
  if(boost::filesystem::exists(file1))
     boost::filesystem::remove(file1); 
  
  if(boost::filesystem::exists(file2))
     boost::filesystem::remove(file2);
}
void removeTmp::removePGM()
{
  if(boost::filesystem::exists(file0))
     boost::filesystem::remove(file0);
}
