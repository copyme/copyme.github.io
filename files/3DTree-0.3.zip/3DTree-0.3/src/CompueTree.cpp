/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    CompueTree.cpp

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "CompueTree.h"
#include "AlgorithmConstData.h"
#include "TreeBranchVoxelizerWithRendomNoise.h"

int SmallBranchCount = 0;

ComputeThread::ComputeThread()
{
  Shape = SimpleOrganShape::New();  
  root = Branch::New(MAX_DIAMETER/2.0,120.0/* + 39.0*/);
  produceBranch = NULL;
  Voxelizer = NULL;
}

ComputeThread::~ComputeThread()
{
  Shape->Delete();
  
  if(Voxelizer)
    delete Voxelizer;
  
  if(produceBranch)
    delete produceBranch;
  
  this->quit();
  this->wait();
}

void ComputeThread::run()
{
  //Kształt organu, w którym rozrasta się drzewo
  Shape->Evaluate();
  Shape->BasicObject::GetTransform()->RotateX(-180);
  Shape->BasicObject::GetTransform()->Scale(10,10,10);
  
  //tchawica
  root->GetTransform()->RotateX(90);
  root->GetTransform()->Translate(0,-(Shape->GetOutput()->GetLength()/4.0)+root->GetHeight()/4.0,0);
  
  root->AddRegion(Shape->GetOutput());
  
  BranchList.push_front(root);

  //restart stanu jesli kilka generowan
  SmallBranchCount = 0;
 
  //Generuje gałęzie drzewa
  produceBranch  = new TreeBranchProducer(BranchList,root,deep, true);
  produceBranch->Start();

  cout << "Branch count: " << BranchList.size() << " Small branch count: " << SmallBranchCount << endl;
  
  //Uruchomienie wokselizacji na wątkach
//  TreeBranchVoxelizerWithRendomNoise *test = new TreeBranchVoxelizerWithRendomNoise(BranchList, spacing);
  Voxelizer = new TreeBranchVoxelizer(BranchList, spacing);
  Voxelizer->Start();
//  test->Start();
  
  endCompute(Voxelizer->GetRawImage(), this);
  exec();
}

#include "CompueTree.moc"
