/*=========================================================================

  Program:   3D Human Airway Tree
  Module:    BasicObject.h

  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

/** @brief Jest to podstawowa klasa wszystkich obiektów.
 * 
 * Klasa ta definiuję wspólne dla wszystkich nadrzędnych klas operacje.
 */

#ifndef BASICOBJ_H
#define BASICOBJ_H

#include <vtkTransform.h>
#include <vtkPolyData.h>
#include <vtkTransformPolyDataFilter.h>
#include <vtkAlgorithmOutput.h>

class BasicObject
{
protected:
  vtkTransform *objTransform;
  vtkTransformPolyDataFilter *polyDataTransFilter;
public:
    BasicObject();
    virtual ~BasicObject();
    //! Zwraca transformację obiektu.
    vtkTransform *GetTransform() const {return objTransform;}
    /** @return wskaźnik na vtkPolyData po zastosowaniu transformacji.
     * 
     * Wszelkie odwołania do danych vtkPolyData powinny następować
     * poprzez tę metodę. Metodę nazwano GetOutput by zachwować
     * kompatybilność z klasami VTK 
     */
    virtual vtkPolyData *GetOutput() const;
    virtual vtkAlgorithmOutput *GetOutputPort() const;
    void Update(){objTransform->Update(); polyDataTransFilter->Update();}
    //! Ustawia połączenie z nadrzędną transformacją.
    void SetPipeline(vtkAlgorithm *objShape)
    {
      //! Dane przekazane jako szablon muszą dziedziczyć z klas vtkAlgorithm
      polyDataTransFilter->SetInputConnection(objShape->GetOutputPort());
      polyDataTransFilter->SetTransform(objTransform);
    }
    void SetPipeline(vtkTransform *relativeTrs, vtkAlgorithm *objShape)
    {
      objTransform->SetInput(relativeTrs);
      objTransform->Update();
      //! Dane przekazane jako szablon muszą dziedziczyć z klas vtkAlgorithm
      polyDataTransFilter->SetInputConnection(objShape->GetOutputPort());
      polyDataTransFilter->SetTransform(objTransform);
    }
};

#endif // BASICOBJ_H
