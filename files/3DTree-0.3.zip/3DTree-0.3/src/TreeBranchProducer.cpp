/*=========================================================================
  
  Program:   3D Human Airway Tree
  Module:    TreeBranchProducer.cpp
  
  Copyright (c) Kacper Pluta <kacperp@wsinf.edu.pl>
  All rights reserved.
  See Copyright.txt or http://leo.wsinf.edu.pl/~kacperp/3dtree for details.
  
     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.
     
=========================================================================*/

#include "TreeBranchProducer.h"
#include <cstdlib>
#include <ctime>
#include <cmath>
#include "CalculateVolumeDividingRatio.h"
#include "SimpleOrganShape.h"
#include "CollisionDetection.h"
#include <vtkPolyDataWriter.h>

TreeBranchProducer::TreeBranchProducer(std::list<boost::shared_ptr<Branch> > &p_list, boost::shared_ptr<Branch> p_masterRoot, int p_rate, bool p_threads) : threads(p_threads), BranchList(p_list),
    root(p_masterRoot)
{
    rate = p_rate;
    detector = new CollisionDetector;
    Distance2Length = LENGTH_RATIO;
    divisorOfSpace = new SpaceDivision;
    cutPlane = NULL;
    
    minFlowRatio = MIN_F_RATIO;
    
    srandom(time(0));
    
    for(int i = 0; i< 4;i++)
        ChildRegions[i] = NULL;
    
    appendPoly = vtkAppendPolyData::New();
    
    clipper = vtkClipPolyData::New();
    clipper->ReleaseDataFlagOn();
    clipper->GenerateClippedOutputOn();
    
    polyCleaner = vtkCleanPolyData::New();
    polyCleaner->ConvertLinesToPointsOn();
    polyCleaner->ConvertPolysToLinesOff();
    polyCleaner->ConvertStripsToPolysOn();
    polyCleaner->PieceInvariantOff();
    polyCleaner->PointMergingOn();
    polyCleaner->ReleaseDataFlagOn();
}
void TreeBranchProducer::ComputeCutPlane(boost::shared_ptr< Branch > branch, float degrees)
{
    if(cutPlane != NULL)
    {
        cutPlane->Delete();
        cutPlane = vtkPlane::New();
    }
    
    cutPlane = vtkPlane::New();
    
    branch->GetTransform()->Update();
    
    /** Płaszczyzna podziału obszaru zorientowana jest o 90˚(reguła 8 i 8a) względem
      * normalnej obiektu dlatego należy przed
      * pobranie normalnej obrócić obiekt względem osi Y
    */    
    branch->GetTransform()->RotateY(-degrees);
    cutPlane->SetOrigin(branch->GetCenter());
    branch->GetTransform()->TransformNormal(cutPlane->GetNormal(),normal);
    cutPlane->SetNormal(normal);
    //! Odtworzenie obrotu gałęzi sprzed stanu przed pobraniem normalnej
    branch->GetTransform()->RotateY(degrees);
}
void TreeBranchProducer::SplitRegion(boost::shared_ptr< Branch > branch)
{
    for(int i = 0;i<4;i++)
    {
        if(ChildRegions[i] != NULL)
        {
            ChildRegions[i]->Delete();
            ChildRegions[i] = NULL;
        }
    }
    
    divisorOfSpace->ClipBoundaries(cutPlane,branch->GetRegion(), ChildRegions);
}

void TreeBranchProducer::SetFlowRatio()
{
    rl = CalculateVolumeDividingRatio(root->GetRegion(),ChildRegions[0]);
    rr = CalculateVolumeDividingRatio(root->GetRegion(),ChildRegions[2]);
    
    if(rl >= rr)
        r = rr;
    else
        r = rl;
    
    if(r <= ERROR_F_RATIO)
        r = MIN_F_RATIO;
    else if(r > MAX_F_RATIO)
        r = MAX_F_RATIO;
    
    
    
    if(r < minFlowRatio)
    {
        if(minFlowRatio == 0.35 && fabs(r - minFlowRatio) > MIN_F_RATIO)
        {
            if(rl >= rr)
            {
                root->GetTransform()->RotateY(-9.0);
                ComputeCutPlane(root);
                SplitRegion(root);
                SetFlowRatio();
            }
            else
            {
                root->GetTransform()->RotateY(9.0);
                ComputeCutPlane(root);
                SplitRegion(root);
                SetFlowRatio();
            }
        }
        else if(minFlowRatio == MIN_F_RATIO)
        {
            if(rl >= rr)
            {
                root->GetTransform()->RotateY(-9.0);
                ComputeCutPlane(root);
                SplitRegion(root);
                SetFlowRatio();
            }
            else
            {
                root->GetTransform()->RotateY(9.0);
                ComputeCutPlane(root);
                SplitRegion(root);
                SetFlowRatio();
            }
        }
    }
}
void TreeBranchProducer::SetBranchingAngle()
{
    angle[0] = acos((1.0+pow(r,4.0/FLOW_P)-pow(1.0-r,4.0/FLOW_P))/(2.0*pow(r,2.0/FLOW_P)))*180/M_PI;
    angle[1] = acos((1.0+pow(1.0-r,4.0/FLOW_P)-pow(r,4.0/FLOW_P))/(2.0*pow(1.0-r,2.0/FLOW_P)))*180/M_PI;
}

void TreeBranchProducer::SetChildDiameters()
{
    diameter[0] = root->GetDiameter()*pow(r,1.0/FLOW_P);
    diameter[1] = root->GetDiameter()*pow(1.0-r,1.0/FLOW_P);
}

void TreeBranchProducer::SetChildLength()
{
    length[0] = (diameter[0]*Distance2Length)+diameter[0]/4.0;
    length[1] = (diameter[1]*Distance2Length)+diameter[1]/4.0;
}

void TreeBranchProducer::TranslateNewBranches(boost::shared_ptr< Branch > Small, boost::shared_ptr< Branch > Big)
{  
    if(rl >= rr)
    {
        //Wyliczenie kątu dla mniejsze gałęzi
        Small->GetTransform()->RotateZ(angle[0]);
        //Wyliczenie pozycji mniejszej gałęzi
        Small->GetTransform()->Translate(0,-(Small->GetHeight()-Small->GetRadius()/2.0),0);
        
        //Wyliczenie kątu dla większej gałęzi
        Big->GetTransform()->RotateZ(-angle[1]);
        //Wyliczenie pozycji mniejszej gałęzi
        Big->GetTransform()->Translate(0,-(Big->GetHeight()-Big->GetRadius()/2.0),0);
        
        //Dodanie regionów do dzieci
        Small->AddRegion(ChildRegions[2]);
        Big->AddRegion(ChildRegions[0]);
    }
    else
    {
        //Wyliczenie kątu dla mniejsze gałęzi
        Small->GetTransform()->RotateZ(-angle[0]);
        //Wyliczenie pozycji mniejszej gałęzi
        Small->GetTransform()->Translate(0,-(Small->GetHeight()-Small->GetRadius()/2.0),0);
        
        //Wyliczenie kątu dla większej gałęzi
        Big->GetTransform()->RotateZ(angle[1]);
        //Wyliczenie pozycji mniejszej gałęzi
        Big->GetTransform()->Translate(0,-(Big->GetHeight()-Big->GetRadius()/2.0),0);
        
        //Dodanie regionów do dzieci
        Small->AddRegion(ChildRegions[0]);
        Big->AddRegion(ChildRegions[2]);
    }
    
    //Zorientowanie planu rozwidlenia dla dzieci prostopadle do ich rodzica
    Small->GetTransform()->RotateY(90.0);
    Big->GetTransform()->RotateY(90.0);  
}

void TreeBranchProducer::GoToNextRecursion(boost::shared_ptr<Branch> Small, boost::shared_ptr<Branch> Big)
{
    //Test czy nie opuszczono regionu gałęzi. Test dla całego organu przeprowadzony gdyż region 
    //gałęzi znajdujących się blisko granicy regionu staje się bardzo płaski
    if(rl >= rr)
    {
        if(!detector->CollisionDetection(ChildRegions[3],Small) && !detector->CollisionDetection(ChildRegions[1],Big) && Small->GetDiameter() >= QC && Big->GetDiameter() >= QC)
        { 
            mutex.lock();  
            BranchList.push_front(Big); 
            BranchList.push_front(Small);
            mutex.unlock();
            
            RemovePunkRegions();
            
            if(threads)
            {
                t_group.create_thread(boost::bind(&TreeBranchProducer::Start,new TreeBranchProducer(BranchList,Small,rate)));
                t_group.create_thread(boost::bind(&TreeBranchProducer::Start,new TreeBranchProducer(BranchList,Big,rate)));
                t_group.join_all();
            }
            else
            {
                Generate(Small);
                Generate(Big);
            }
        }
        else
        {
            //cout << "error" << endl;
            RemovePunkRegions();
            Small.reset();
            Big.reset();
        }
    }
    else
    {
        if(!detector->CollisionDetection(ChildRegions[1],Small) && !detector->CollisionDetection(ChildRegions[3],Big) && Small->GetDiameter() >= QC && Big->GetDiameter() >= QC)
        { 
            
            mutex.lock();  
            BranchList.push_front(Big); 
            BranchList.push_front(Small);
            mutex.unlock();
            
            RemovePunkRegions();
            
            if(threads)
            {
                t_group.create_thread(boost::bind(&TreeBranchProducer::Start,new TreeBranchProducer(BranchList,Small,rate)));
                t_group.create_thread(boost::bind(&TreeBranchProducer::Start,new TreeBranchProducer(BranchList,Big,rate)));
                t_group.join_all();
            }
            else
            {
                Generate(Small);
                Generate(Big);
            }
        }
        else
        {
            //cout << "error" << endl;
            RemovePunkRegions();
            Small.reset();
            Big.reset();
        }
    }
}
/*
 * Implementacja reguły 4a jest nie dokonca zgodna z opisem.
 * Aktualizowane sa wszystkie dane poza ksztaltem regionu.
 * proby wygenerowania nowego regionu za pomoca operacji Boolowskich
 * lub standardowego mechanizmu z ClipBoundaries(); nie daja poprawnego regionu
 */
void TreeBranchProducer::Rule4a()
{
    if(fabs(angle[0] - angle[1]) >= 10.0)
    {
        /*
     * W celu określenia siecznej generujemy nową tymczasową gałąź o średnicy
     * rodzica i jaknajmniejszej długości. Następnie dokonywana jest rotacja
     * gałęzi tymczasowej w kierunku siecznej kąta rozwidlenia.
     */
        
        SetPatella();
        
        //cout << " rule 4a " << endl;
        vtkPolyData *tmp[4] = {NULL,NULL,NULL,NULL};
        vtkPolyData *tmp2[4] = {NULL,NULL,NULL,NULL};
        
        //Sieczna zawsze znajduje się w kierunku mniejszej gałęzi
        if(rl >= rr)
        {
            Patella->GetTransform()->RotateZ(fabs(angle[0] - angle[1])/2.0);
            Patella->GetTransform()->Translate(0,-Patella->GetHeight(),0);
            
            ComputeCutPlane(Patella);
            
            divisorOfSpace->ClipBoundaries(cutPlane,ChildRegions[2],tmp);
            divisorOfSpace->ClipBoundaries(cutPlane,ChildRegions[3],tmp2);
            
            if(tmp[2] != NULL && tmp2[1] != NULL)
            {
                appendPoly->RemoveAllInputs();
                appendPoly->AddInput(ChildRegions[1]);
                appendPoly->AddInput(tmp2[1]);
                
                polyCleaner->RemoveAllInputs();
                polyCleaner->SetInput(appendPoly->GetOutput());
                
                
                ChildRegions[0]->Delete();
                ChildRegions[0] = vtkPolyData::New();
                
                divisorOfSpace->RemoveAllInputs();
                ChildRegions[0]->DeepCopy(divisorOfSpace->AddBoundary(polyCleaner->GetOutput()));
                
                ChildRegions[1]->Delete();
                ChildRegions[1] = vtkPolyData::New();
                ChildRegions[1]->DeepCopy(polyCleaner->GetOutput());
                
                ChildRegions[2]->Delete();
                ChildRegions[2] = vtkPolyData::New();
                ChildRegions[2]->DeepCopy(tmp[2]);
                
                ChildRegions[3]->Delete();
                ChildRegions[3] = vtkPolyData::New();
                ChildRegions[3]->DeepCopy(tmp2[3]);
                
                //remove
                // 	vtkPolyDataWriter *w = vtkPolyDataWriter::New();
                // 	w->SetFileTypeToBinary();
                // 	w->SetFileName("dane.poly");
                // 	w->SetInput(tmp2[3]);
                // 	w->Write();
                // 	w->Update();
                //end remove
                
                //zaktualizuj wspolcznnik podzialu objętosci	
                rl = CalculateVolumeDividingRatio(root->GetRegion(),appendPoly->GetOutput());
                rr = CalculateVolumeDividingRatio(root->GetRegion(),tmp[2]);
                
                if(rl >= rr)
                    r = rr;
                else
                    r = rl;
                
                if(r <= ERROR_F_RATIO)
                    r = MIN_F_RATIO;
                else if(r > MAX_F_RATIO)
                    r = MAX_F_RATIO;
                
                SetChildDiameters();
                SetBranchingAngle();
                
                //czysczenie plików tymczasowych
                for(int i = 0; i < 4;i++)
                {
                    tmp[i]->Delete();
                    tmp[i] = NULL;
                    tmp2[i]->Delete();
                    tmp2[i] = NULL;
                }
                Rule6a();
            }
            else
            {
                flag = false;
            }
        }
        else
        {
            Patella->GetTransform()->RotateZ(fabs(angle[0] - angle[1])/-2.0);
            Patella->GetTransform()->Translate(0,-Patella->GetHeight(),0);
            
            ComputeCutPlane(Patella);
            
            divisorOfSpace->ClipBoundaries(cutPlane,ChildRegions[0],tmp);
            divisorOfSpace->ClipBoundaries(cutPlane,ChildRegions[1],tmp2);
            
            
            if(tmp[0] != NULL && tmp2[3] != NULL)
            {
                appendPoly->RemoveAllInputs();
                appendPoly->AddInput(ChildRegions[3]);
                appendPoly->AddInput(tmp2[3]);
                
                polyCleaner->RemoveAllInputs();
                polyCleaner->SetInput(appendPoly->GetOutput());
                
                ChildRegions[2]->Delete();
                ChildRegions[2] = vtkPolyData::New();
                
                divisorOfSpace->RemoveAllInputs();
                ChildRegions[2]->DeepCopy(divisorOfSpace->AddBoundary(polyCleaner->GetOutput()));
                
                ChildRegions[3]->Delete();
                ChildRegions[3] = vtkPolyData::New();
                ChildRegions[3]->DeepCopy(polyCleaner->GetOutput());
                
                ChildRegions[0]->Delete();
                ChildRegions[0] = vtkPolyData::New();
                ChildRegions[0]->DeepCopy(tmp[0]);
                
                ChildRegions[1]->Delete();
                ChildRegions[1] = vtkPolyData::New();
                ChildRegions[1]->DeepCopy(tmp2[1]);
                
                rr = CalculateVolumeDividingRatio(root->GetRegion(),appendPoly->GetOutput());
                rl = CalculateVolumeDividingRatio(root->GetRegion(),tmp[0]);
                
                //remove
                // 	vtkPolyDataWriter *w = vtkPolyDataWriter::New();
                // 	w->SetFileTypeToBinary();
                // 	w->SetFileName("dane.poly");
                // 	w->SetInput(tmp2[1]);
                // 	w->Write();
                // 	w->Update();
                //end - remove
                
                if(rl >= rr)
                    r = rr;
                else
                    r = rl;
                
                if(r <= ERROR_F_RATIO)
                    r = MIN_F_RATIO;
                else if(r > MAX_F_RATIO)
                    r = MAX_F_RATIO;
                
                SetChildDiameters();
                SetBranchingAngle();
                
                //czysczenie plików tymczasowych
                for(int i = 0; i < 4;i++)
                {
                    tmp[i]->Delete();
                    tmp[i] = NULL;
                    tmp2[i]->Delete();
                    tmp2[i] = NULL;
                }
                Rule6a();
            }
            else
            {
                flag = false;
            }
        }
    }
}

int TreeBranchProducer::Rule6a()
{
    double psiAngle;
    
    if(rl >= rr)
    {
        psiAngle = ComputeCenterOfVolume(0.3,0.01,ChildRegions[2], length[0]);
        
        if(psiAngle >= 180.0)
        {
            psiAngle = ComputeCenterOfVolume(0.1,0.01,ChildRegions[2], length[0]);
        }
        
        if(psiAngle >= 180.0)
        {
            std::cerr << psiAngle << endl;
            flag = false;
            return -1;
        }
        
        if(angle[0] < psiAngle)
        {
            angle[0] = (psiAngle + angle[0])/2.0;
            
            if(angle[0] > 90.0)
            {
                angle[0] = 90.0;
            }
        }
        
        psiAngle = ComputeCenterOfVolume(-0.3,0.01,ChildRegions[0], length[1]);
        
        if(psiAngle >= 180.0)
        {
            psiAngle = ComputeCenterOfVolume(-0.1,0.01,ChildRegions[0], length[1]);
        }
        
        if(psiAngle >= 180.0)
        {
            std::cerr << psiAngle << endl;
            flag = false;
            return -1;
        }
        
        if(angle[1] < psiAngle)
        {
            angle[1] = (psiAngle + angle[1])/2.0;
            
            if(angle[1] > 90.0)
            {
                angle[1] = 90.0;
            }
        }
    }
    else
    {
        psiAngle = ComputeCenterOfVolume(-0.3,0.01,ChildRegions[0], length[0]);
        
        if(psiAngle >= 180.0)
        {
            psiAngle = ComputeCenterOfVolume(-0.1,0.01,ChildRegions[0], length[0]);
        }
        if(psiAngle >= 180.0)
        {
            std::cerr << psiAngle << endl;
            flag = false;
            return -1;
        }
        
        //cout << "angle0 " << angle[0] << " " << psiAngle << endl;
        if(angle[0] < psiAngle)
        {
            angle[0] = (psiAngle + angle[0])/2.0;
            
            if(angle[0] > 90.0)
            {
                angle[0] = 90.0;
            }
        }
        
        psiAngle = ComputeCenterOfVolume(0.3,0.01,ChildRegions[2], length[1]);
        
        if(psiAngle >= 180.0)
        {
            psiAngle = ComputeCenterOfVolume(0.1,0.01,ChildRegions[2], length[1]);
        }
        
        if(psiAngle >= 180.0)
        {
            std::cerr << psiAngle << endl;
            flag = false;
            return -1;
        }
        
        if(angle[1] < psiAngle)
        {
            angle[1] = (psiAngle + angle[1])/2.0;
            
            if(angle[1] > 90.0)
            {
                angle[1] = 90.0;
            }
        }
    }
    return 1;
}

double TreeBranchProducer::ComputeCenterOfVolume(double step, float precision, vtkPolyData *region, double branchLenght)
{   
    clipper->RemoveAllInputs();
    
    vtkPolyData *tmp[2] = {NULL, NULL};
    
    volumeTmp[0] = 1000;
    volumeTmp[1] = 1;
    
    double i = 0.0;
    
    while(fabs(volumeTmp[0] - volumeTmp[1]) >= precision && fabs(i) <= 180.0)
    {
        i += step;
        
        SetPatella(branchLenght);
        Patella->GetTransform()->RotateZ(i);
        Patella->GetTransform()->Translate(0,-Patella->GetHeight(),0);
        Patella->GetTransform()->Update();
        
        ComputeCutPlane(Patella);
        
        clipper->RemoveAllInputs();
        
        clipper->SetInput(region);
        
        clipper->SetClipFunction(cutPlane);
        
        clipper->Update();
        
        if(clipper->GetClippedOutput()->GetNumberOfPolys() > 0 && clipper->GetOutput()->GetNumberOfPolys() > 0)
        {
            tmp[0] = clipper->GetOutput();
            tmp[1] = clipper->GetClippedOutput();
            volumeTmp[0] = CalculateVolumeDividingRatio(region,tmp[0]);
            volumeTmp[1] = CalculateVolumeDividingRatio(region,tmp[1]);
        }
    }
    return fabs(i);
}

void TreeBranchProducer::Generate(boost::shared_ptr<Branch> branch)
{  
    if(branch->GetDiameter() > static_cast<double>(rate))
    { 
        root = branch;
        flag = true;
        //     //cout << "ok 0" <<endl;
        //Normalna płaszczyzny podziału musi być prostopadła względem planu rozwidlenia  
        ComputeCutPlane(root);
        SplitRegion(root);
        //     //cout << "ok 1" <<endl;
        //Jeśli wartość tmp jest NULL oznacza to że nie udało się wyegerować regionu dla nowych gałęzi
        //W takim wypadku należy zakończyć generowanie drzewa
        if(ChildRegions[0] != NULL && ChildRegions[2] != NULL)
        {
            if(root->GetDiameter() < static_cast<double>(rate) * 1.5)
            {
                minFlowRatio = 0.35;
            }
            else
            {
                minFlowRatio = MIN_F_RATIO;
            }
            //Obliczamy współczynik podziału przestrzeni
            SetFlowRatio();
            //Obliczenie kątu dla gałęzi
            SetBranchingAngle();
            //Obliczenie średnicy gałezi
            SetChildDiameters();
            //Obliczenie średnicy gałęzi
            SetChildLength();
            Rule7a();
            cout << "ok 2" <<endl;
            Rule4a();
            cout << "ok 4a " << endl;
            //Jesli flaga jest ok przehdzi dalej.
            if(flag)
            {
                boost::shared_ptr<Branch> NewSmall = Branch::New(diameter[0]/2.0, length[0], root->GetTransform(), root->GetEQ());
                boost::shared_ptr<Branch> NewBig = Branch::New(diameter[1]/2.0, length[1], root->GetTransform(), root->GetEQ());
                
                TranslateNewBranches(NewSmall,NewBig);
                //cout << "ok 4" <<endl;
                GoToNextRecursion(NewSmall, NewBig);
            }
        }
    } else {
        SmallBranchCount++;
        root->SetIsEnd();
    }
}

void TreeBranchProducer::Rule7a()
{
    cout << " rule7a " << endl;
    SetPatella(length[0],diameter[0]);
    vtkPolyData *region;
    
    if(rl >= rr)
    {
        Patella->GetTransform()->RotateZ(angle[0]);
        Patella->GetTransform()->Translate(0,-Patella->GetHeight(),0);
        region = ChildRegions[3];
    }
    else
    {
        Patella->GetTransform()->RotateZ(-angle[0]);
        Patella->GetTransform()->Translate(0,-Patella->GetHeight(),0);
        region = ChildRegions[1];
    }
    
    float i = 0.0;
    
    //wyznacz odleglosc do krawedzi
    while(!detector->CollisionDetection(region,Patella))
    {
        i += root->GetDiameter()/2.0;
        
        SetPatella(length[0]+i,diameter[0]);
        
        if(rl >= rr)
        {
            Patella->GetTransform()->RotateZ(angle[0]);
            Patella->GetTransform()->Translate(0,-Patella->GetHeight(),0);
        }
        else
        {
            Patella->GetTransform()->RotateZ(-angle[0]);
            Patella->GetTransform()->Translate(0,-Patella->GetHeight(),0);
        } 
    }
    
    double tmpLen[2];
    double d = 3.0;
    cout << "1 " << endl;
    tmpLen[0] = diameter[0]*d;
    
    while(d > 1.0)
    {
        if((((length[0]-diameter[0]/4) + i) / tmpLen[0]) > 6.0)
        {
            d += 0.25;
            tmpLen[0] = diameter[0]*d;
        }
        else if ((((length[0]-diameter[0]/4) + i) / tmpLen[0]) < 3.0)
        {
            d -= 0.25;
            tmpLen[0] = diameter[0]*d;
        }
        if((((length[0]-diameter[0]/4) + i) / tmpLen[0]) <= 6.0 && (((length[0]-diameter[0]/4) + i) / tmpLen[0]) >= 3.0)
        {
            break;
        }
    }
    length[0] = tmpLen[0]+diameter[0]/4;
    cout << " d1 " << d  << endl;
    
    
    //druga galaz
    SetPatella(length[1],diameter[1]);
    
    
    if(rl >= rr)
    {
        Patella->GetTransform()->RotateZ(-angle[1]);
        Patella->GetTransform()->Translate(0,-Patella->GetHeight(),0);
        region = ChildRegions[1];
    }
    else
    {
        Patella->GetTransform()->RotateZ(angle[1]);
        Patella->GetTransform()->Translate(0,-Patella->GetHeight(),0);
        region = ChildRegions[3];
    }
    
    i = 0.0;
    //wyznacz odleglosc do krawedzi
    while(!detector->CollisionDetection(region,Patella))
    {
        i+= root->GetDiameter()/2.0;
        
        SetPatella((length[1]-diameter[1]/4) + i,diameter[1]);
        
        if(rl >= rr)
        {
            Patella->GetTransform()->RotateZ(-angle[1]);
            Patella->GetTransform()->Translate(0,-Patella->GetHeight(),0);
        }
        else
        {
            Patella->GetTransform()->RotateZ(angle[1]);
            Patella->GetTransform()->Translate(0,-Patella->GetHeight(),0);
        }
    }
    
    d = 3.0;
    cout << "2 " << endl;
    tmpLen[1] = diameter[1]*d;
    
    while(d > 1.0)
    {
        if((((length[1]-diameter[1]/4) + i) / tmpLen[1]) > 6.0)
        {
            d += 0.25;
            tmpLen[1] = diameter[1]*d;
        }
        else if ((((length[1]-diameter[1]/4) + i) / tmpLen[1]) < 3.0)
        {
            d -= 0.25;
            tmpLen[1] = diameter[1]*d;
        }
        if((((length[1]-diameter[1]/4) + i) / tmpLen[1]) <= 6.0 && (((length[1]-diameter[1]/4) + i) / tmpLen[1]) >= 3.0)
        {
            break;
        }
    }  
    length[1] = tmpLen[1]+diameter[1]/4;
    cout << " d2 " << d  << endl;
}


void TreeBranchProducer::Start()
{
    Generate(root);
}
TreeBranchProducer::~TreeBranchProducer()
{
    clipper->Delete();
    polyCleaner->Delete();
    appendPoly->Delete();
    Patella.reset();
    delete detector;
    delete divisorOfSpace;
}

void TreeBranchProducer::RemovePunkRegions()
{
    ChildRegions[1]->Delete();
    ChildRegions[1] = NULL;
    ChildRegions[3]->Delete();
    ChildRegions[3] = NULL;
    root->RemoveRegion();
    
    cutPlane->Delete();
    cutPlane = NULL;
}
