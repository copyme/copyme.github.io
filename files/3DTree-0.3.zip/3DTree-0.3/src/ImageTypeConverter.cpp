#include "ImageTypeConverter.h"
#include <vtkImageImport.h>
#include <mccodimage.h>
#include <mcimage.h>

vtkSmartPointer< vtkImageData > ImageTypeConverter::PinkToVTK( const xvimage * pinkImage, double * origin ) {
  
  int size[3];
  size[0] = pinkImage->row_size;
  size[1] = pinkImage->col_size;
  size[2] = pinkImage->depth_size;
  
  int tmpStart[3];
  tmpStart[0] = pinkImage->xmin;
  tmpStart[1] = pinkImage->ymin;
  tmpStart[2] = pinkImage->zmin;
  
  double spacing[3];
  spacing[0] = pinkImage->xdim;
  spacing[1] = pinkImage->ydim;
  spacing[2] = pinkImage->zdim;
  
  
  vtkSmartPointer< vtkImageImport > imageImport = vtkSmartPointer< vtkImageImport >::New();
  
  imageImport->SetDataOrigin(origin);
  imageImport->SetDataScalarTypeToUnsignedChar();
  imageImport->SetDataSpacing(spacing);
  imageImport->SetWholeExtent(tmpStart[0], size[0] -1 , tmpStart[1], size[1] - 1, tmpStart[2], size[2] -1 );
  imageImport->SetDataExtentToWholeExtent();
  imageImport->SetImportVoidPointer(pinkImage->image_data);
  imageImport->Update();

  
  return imageImport->GetOutput();
  
}

xvimage * const ImageTypeConverter::VTKToPink( vtkImageData * vtkImage ) {
    
    xvimage *tmpPink = new xvimage;
    
    tmpPink->name = NULL;
    int dims[3];
    vtkImage->GetDimensions(dims);
    tmpPink->name = NULL;
    tmpPink->row_size = dims[0];
    tmpPink->col_size = dims[1];
    tmpPink->depth_size = dims[2];
    
    tmpPink->time_size = 1;
    tmpPink->num_data_bands = 1;
    
    tmpPink->d = vtkImage->GetDataDimension();
    tmpPink->xdim = vtkImage->GetSpacing()[0];
    tmpPink->ydim = vtkImage->GetSpacing()[1];
    tmpPink->zdim = vtkImage->GetSpacing()[2];
    
    tmpPink->xmin = 0;
    tmpPink->xmax = tmpPink->xdim -1;
    
    tmpPink->ymin = 0;
    tmpPink->ymax = tmpPink->ydim -1;
    
    tmpPink->zmin = 0;
    tmpPink->zmax = tmpPink->zdim -1;
    
    tmpPink->data_storage_type = VFF_TYP_1_BYTE;
    
    tmpPink->image_data = calloc(1, VFF_TYP_1_BYTE * (tmpPink->row_size * tmpPink->col_size * tmpPink->depth_size));
    
    memcpy(tmpPink->image_data, vtkImage->GetScalarPointer(), sizeof (unsigned char) * (tmpPink->row_size * tmpPink->col_size * tmpPink->depth_size));
    
//    writeimage(tmpPink, "/home/kacper/test.pgm");
    
    return tmpPink;
    
}
